package in.example.user1.UI;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.hsalf.smilerating.SmileRating;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import in.example.user1.R;
import in.example.user1.model.Jobs;
import in.example.user1.model.ReviewItem;
import in.example.user1.model.StarItem;

import static in.example.user1.model.SharedClass.CUSTOMER_PATH;
import static in.example.user1.model.SharedClass.RESTAURATEUR_INFO;
import static in.example.user1.model.SharedClass.ROOT_UID;
import static in.example.user1.model.SharedClass.user;

class JobsAdapter extends RecyclerView.Adapter<JobsAdapter.ViewHolder> {

    private Context context;
    private ArrayList<Jobs> arrayList;
    private ArrayList<String> stringArrayList;
    View view;

    public JobsAdapter(Context context, ArrayList<Jobs> arrayList, ArrayList<String> stringArrayList) {
        this.context = context;
        this.arrayList = arrayList;
        this.stringArrayList = stringArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        switch (viewType) {
            case 1:
                return new JobRequest(LayoutInflater.from(parent.getContext()).inflate(R.layout.job_request_row, parent, false));
            case 2:
                return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.rejected_job_layout, parent, false));
        }
        return new JobRequest(LayoutInflater.from(parent.getContext()).inflate(R.layout.job_request_row, parent, false));

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Log.d("jobs", arrayList.get(position).toString());
        final Jobs jobs = arrayList.get(position);
        Log.d("jobsadapter", arrayList.get(position).toString());

        String key = stringArrayList.get(position);
        Date iDate = jobs.getT().toDate();

        SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
        DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

        String dateString = dateFormatter.format(iDate);
        String timeString = timeFormat.format(iDate);

        holder.notif_day.setText(dateString);
        holder.notif_time.setText(timeString);

        switch (holder.getItemViewType()) {
            case 1:
                final String[] phone = new String[1];
                final String[] photoPath = new String[1];
                final String[] name = new String[1];
                FirebaseFirestore.getInstance().collection("Home Enterpreneurs").document(jobs.getU()).get()
                        .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    DocumentSnapshot d = task.getResult();
                                    holder.notif_msg.setText("Job Request Details");
                                    ((JobRequest) holder).address.setText(d.get("add").toString());
                                    phone[0] = d.get("ph").toString();

                                    name[0] = d.get("n").toString();
                                    ((JobRequest) holder).phone.setText(phone[0]);

                                    if (d.contains("pu")) {
                                        photoPath[0] = d.get("pu").toString();
                                        Glide.with(context)
                                                .load(d.get("pu").toString())
                                                .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                                                .placeholder(R.drawable.ic_male)
                                                .dontAnimate()
                                                .centerInside()
                                                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                                .into(holder.notifDp);
                                    } else {
                                        Glide.with(context)
                                                .load(R.drawable.person)
                                                .placeholder(R.drawable.ic_male)
                                                .dontAnimate()
                                                .centerInside()
                                                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                                .into(holder.notifDp);
                                    }
                                }
                            }
                        });
                holder.response.setText("Accepted");
                ((JobRequest) holder).call.setOnClickListener(v -> {
                    Intent callIntent = new Intent(Intent.ACTION_CALL);
                    Log.d("phone", phone[0].toString());
                    callIntent.setData(Uri.parse("tel:" + "+91" + phone[0]));//change the number
                    if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                        // TODO: Consider calling
                        //    ActivityCompat#requestPermissions
                        // here to request the missing permissions, and then overriding
                        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                        //                                          int[] grantResults)
                        // to handle the case where the user grants the permission. See the documentation
                        // for ActivityCompat#requestPermissions for more details.
                        return;
                    }
                    context.startActivity(callIntent);
                });

                ((JobRequest) holder).btnCompleted.setOnClickListener(v -> {
                    AlertDialog dialog = new AlertDialog.Builder(context)
                            .setTitle("By clicking you assure that the job is completed. Please rate the worker")
                            .setPositiveButton("Yes", (d, i) -> {
                                FirebaseDatabase.getInstance().getReference("notifications").child(jobs.getU()).child("jobs").child(key).child("c").setValue(3);
                                FirebaseDatabase.getInstance().getReference("user_notifications").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("jobs").child(key).child("c").setValue(3);
                            })
                            .setNegativeButton("No", null)
                            .create();
                    dialog.show();
                });

                ((JobRequest) holder).btnReview.setOnClickListener(v -> {
                    showAlertDialogDelivered(FirebaseAuth.getInstance().getCurrentUser().getUid(), stringArrayList.get(position),position);
                });


                break;
            case 2:
                FirebaseFirestore.getInstance().collection("Home Enterpreneurs").document(jobs.getU()).get()
                        .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    DocumentSnapshot d = task.getResult();
                                    holder.notif_msg.setText("Job Request Details");
                                    if (d.contains("pu")) {
                                        Glide.with(context)
                                                .load(d.get("pu").toString())
                                                .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                                                .placeholder(R.drawable.ic_male)
                                                .dontAnimate()
                                                .centerInside()
                                                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                                .into(holder.notifDp);
                                    } else {
                                        Glide.with(context)
                                                .load(R.drawable.person)
                                                .placeholder(R.drawable.ic_male)
                                                .dontAnimate()
                                                .centerInside()
                                                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                                .into(holder.notifDp);
                                    }
                                }
                            }
                        });
                holder.response.setText("Rejected");
                break;
        }

    }
    public View getView() {
        return view;
    }

    private void showAlertDialogDelivered(String resKey, String orderKey, int position) {
        Query query = FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO).child(resKey).child("info");
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                AlertDialog alertDialog = new AlertDialog.Builder(view.getContext()).create();
                LayoutInflater factory = LayoutInflater.from(view.getContext());
                final View view = factory.inflate(R.layout.rating_dialog, null);
                SmileRating smileRating = (SmileRating) view.findViewById(R.id.dialog_rating_rating_bar);
                //Button confirm pressed
                view.findViewById(R.id.dialog_rating_button_positive).setOnClickListener(a -> {
                    if (smileRating.getRating() != 0) {
                        DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("restaurants" + "/" + resKey).child("review");
                        DatabaseReference myRef2 = FirebaseDatabase.getInstance().getReference("user_notifications").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                .child("jobs").child(orderKey);
                        final String[] photoPath = new String[1];
                        final String[] name = new String[1];
                        FirebaseFirestore.getInstance().collection("Home Enterpreneurs").document(arrayList.get(position).getU()).get()
                                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                        if (task.isSuccessful()) {
                                            DocumentSnapshot d = task.getResult();
                                            name[0] = d.get("n").toString();
                                            if (d.contains("pu")) {
                                                photoPath[0] = d.get("pu").toString();
                                            }
                                        }
                                    }
                                });
                        HashMap<String, Object> rated = new HashMap<>();
                        HashMap<String, Object> review = new HashMap<>();
                        String comment = ((EditText) view.findViewById(R.id.dialog_rating_feedback)).getText().toString();
                        updateRestaurantStars(resKey, smileRating.getRating());
                        if (!comment.isEmpty()) {
                            rated.put("rated", true);
                            myRef2.updateChildren(rated);
                            review.put(myRef.push().getKey(), new ReviewItem(smileRating.getRating(), comment, ROOT_UID,photoPath[0], name[0]));
                            myRef.updateChildren(review);
                        } else {
                            rated.put("rated", true);
                            myRef2.updateChildren(rated);
                            review.put(myRef.push().getKey(), new ReviewItem(smileRating.getRating(), null, ROOT_UID,photoPath[0], name[0]));
                            myRef.updateChildren(review);
                        }
                        Toast.makeText(view.getContext(), "Thanks for your review!", Toast.LENGTH_LONG).show();
                        alertDialog.dismiss();
                    } else {
                        Toast.makeText(view.getContext(), "You forgot to rate!", Toast.LENGTH_LONG).show();
                    }
                });
                view.findViewById(R.id.dialog_rating_button_negative).setOnClickListener(b -> {
                    alertDialog.dismiss();
                });
                alertDialog.show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    private void updateRestaurantStars(String resKey, int stars) {
        Query query = FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO).child(resKey).child("stars");
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                HashMap<String, Object> star = new HashMap<>();
                DatabaseReference myRef = FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO + "/" + resKey);
                if (dataSnapshot.exists()) {
                    int s = ((Long) dataSnapshot.child("tot_stars").getValue()).intValue();
                    int p = ((Long) dataSnapshot.child("tot_review").getValue()).intValue();
                    star.put("stars", new StarItem(s + stars, p + 1, -s - stars));
                    myRef.updateChildren(star);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void setRated(String orderKey, boolean bool) {
        DatabaseReference myRef2 = FirebaseDatabase.getInstance().getReference("user_notifications").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .child("jobs").child(orderKey);
        HashMap<String, Object> rated = new HashMap<>();
        rated.put("rated", bool);
        myRef2.updateChildren(rated);
    }

    @Override
    public int getItemViewType(int position) {
        if (arrayList.get(position).getC() == 2 || arrayList.get(position).getC() == 3 || arrayList.get(position).getC() == 4) {
            return 1;
        } else if (arrayList.get(position).getC() == 5) {
            return 2;
        }
        return 1;
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView notifDp;
        private TextView notif_msg, notif_day, notif_time, response;
        private ConstraintLayout bgCard;
        private RatingBar ratingBar;
        private TextView rating;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            view = itemView;
            rating = itemView.findViewById(R.id.rating);
            ratingBar = itemView.findViewById(R.id.ratingBaritem);
            notifDp = itemView.findViewById(R.id.notifDp);
            notif_msg = itemView.findViewById(R.id.notif_msg);
            notif_day = itemView.findViewById(R.id.notif_day);
            notif_time = itemView.findViewById(R.id.notif_time);
            bgCard = itemView.findViewById(R.id.bgCard);
            response = itemView.findViewById(R.id.response);
        }

    }

    class JobRequest extends ViewHolder {
        private TextView address, phone;
        private ImageView call;
        private Button btnCompleted, btnReview;

        public JobRequest(@NonNull View itemView) {
            super(itemView);
            view = itemView;
            call = itemView.findViewById(R.id.call);
            address = itemView.findViewById(R.id.address);
            phone = itemView.findViewById(R.id.phone);
            btnCompleted = itemView.findViewById(R.id.btnCompleted);
            btnReview = itemView.findViewById(R.id.btnReview);
        }
    }
}


