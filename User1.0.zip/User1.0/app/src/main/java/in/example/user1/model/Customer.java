package in.example.user1.model;

import android.os.Parcel;
import android.os.Parcelable;

public final class Customer implements Parcelable {
    public String n;
    public String e;
    public double lt;
    public double lon;
    public String p;
    public String add;
    public String pu;

    public Customer()
    {
        n = "";
        e = "";
        lt = 0.0;
        lon = 0.0;
        p = "";
        add = "";
        pu = "";
    }
    protected Customer(Parcel in) {
        n = in.readString();
        e = in.readString();
        lt = in.readDouble();
        lon = in.readDouble();
        p = in.readString();
        add = in.readString();
        pu = in.readString();
    }

    public Customer(String n, String e, double lt, double lon, String p, String add, String pu) {
        this.n = n;
        this.e = e;
        this.lt = lt;
        this.lon = lon;
        this.p = p;
        this.add = add;
        this.pu = pu;
    }

    public String getN() {
        return n;
    }

    public void setN(String n) {
        this.n = n;
    }

    public String getE() {
        return e;
    }

    public void setE(String e) {
        this.e = e;
    }

    public double getLt() {
        return lt;
    }

    public void setLt(double lt) {
        this.lt = lt;
    }

    public double getLon() {
        return lon;
    }

    public void setLon(double lon) {
        this.lon = lon;
    }

    public String getP() {
        return p;
    }

    public void setP(String phone) {
        this.p = phone;
    }

    public String getAdd() {
        return add;
    }

    public void setAdd(String add) {
        this.add = add;
    }

    public String getPu() {
        return pu;
    }

    public void setPu(String pu) {
        this.pu = pu;
    }


    public static final Creator<Customer> CREATOR = new Creator<Customer>() {
        @Override
        public Customer createFromParcel(Parcel in) {
            return new Customer(in);
        }

        @Override
        public Customer[] newArray(int size) {
            return new Customer[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(n);
        dest.writeString(e);
        dest.writeDouble(lt);
        dest.writeDouble(lon);
        dest.writeString(p);
        dest.writeString(add);
        dest.writeString(pu);
    }
}
