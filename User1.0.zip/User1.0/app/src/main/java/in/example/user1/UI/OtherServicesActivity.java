package in.example.user1.UI;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;
import in.example.user1.R;
import in.example.user1.model.Customer;
import in.example.user1.model.Restaurateur;

public class OtherServicesActivity extends AppCompatActivity {

    //c = 1 Job has been placed
    //c = 2  Job has been accepted by the worker
    //c = 3 Job completed, otp matches
    //c = 4 rated by the user
    //c = 5 request declined by the user
    private Restaurateur restaurateur;
    private TextView profession, name, btnConfirm;
    private CircleImageView circleImageView;
    private TextView date, time;
    private int year, month, day, hour, minute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other_services);

        restaurateur = getIntent().getParcelableExtra("details");
        profession = findViewById(R.id.profession);
        name = findViewById(R.id.name);
        circleImageView = findViewById(R.id.img_profile);

        profession.setText(restaurateur.getProfession());
        name.setText(restaurateur.getName());

        btnConfirm = findViewById(R.id.btnConfirm);
        if (restaurateur.getPhotoUri() != null)
            Glide.with(Objects.requireNonNull(this))
                    .load(restaurateur.getPhotoUri())
                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                    .placeholder(R.drawable.ic_male)
                    .dontAnimate()
                    .centerInside()
                    .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                    .into(circleImageView);
        else {
            Glide.with(Objects.requireNonNull(this))
                    .load(R.drawable.person)
                    .placeholder(R.drawable.ic_male)
                    .dontAnimate()
                    .centerInside()
                    .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                    .into(circleImageView);
        }

        year = month = day = hour = minute = -1;
        date = findViewById(R.id.date);

        time = findViewById(R.id.time);

        date.setOnClickListener(view -> {
            Calendar calendar = Calendar.getInstance();
            DatePickerDialog datePickerDialog = new DatePickerDialog(OtherServicesActivity.this,
                    (view2, year, monthOfYear, dayOfMonth) -> {
                        OtherServicesActivity.this.year = year;
                        OtherServicesActivity.this.day = dayOfMonth;
                        OtherServicesActivity.this.month = monthOfYear;
                        date.setText(generateDate(year, monthOfYear, dayOfMonth));
                    }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
            datePickerDialog.show();
        });

        time.setOnClickListener(view -> {
            Calendar calendar = Calendar.getInstance();
            TimePickerDialog mTimePicker;
            mTimePicker = new TimePickerDialog(OtherServicesActivity.this, (timePicker, selectedHour, selectedMinute) -> {
                OtherServicesActivity.this.hour = selectedHour;
                OtherServicesActivity.this.minute = selectedMinute;
                time.setText(generateTime(selectedHour, selectedMinute));
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false);//Yes 24 hour time
            mTimePicker.setTitle("Select Time");
            mTimePicker.show();
        });

        btnConfirm.setOnClickListener(v -> {
            Date date;
            if (year == -1 || hour == -1) {
                Toast.makeText(this, "Select data and time", Toast.LENGTH_SHORT).show();
                return;
            } else {
                date = getDate(year, month, day, hour, minute);
            }

            int otp = (int) (Math.random() * 10000);
            if (otp < 1000) otp += 1000;

            String order_id = FirebaseDatabase.getInstance().getReference().push().getKey();
            String notif_key = "notifications/" + restaurateur.getUid() + "/jobs/" + order_id + "/";
            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put(notif_key + "t", date.getTime());
            hashMap.put(notif_key + "u", FirebaseAuth.getInstance().getCurrentUser().getUid());
            hashMap.put(notif_key + "c", 1);
            hashMap.put(notif_key + "otp", otp);
            FirebaseDatabase.getInstance().getReference().updateChildren(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(OtherServicesActivity.this, "The job has been scheduled. Please keep checking your order history for status", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(OtherServicesActivity.this, NavApp.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    } else {
                        Toast.makeText(OtherServicesActivity.this, "The job cannot be created", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(OtherServicesActivity.this, NavApp.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }
                }
            });

            String notif_key_1 = "user_notifications/" + FirebaseAuth.getInstance().getCurrentUser().getUid() + "/jobs/" + order_id + "/";

            HashMap<String, Object> hashMap1 = new HashMap<>();
            hashMap1.put(notif_key_1 + "t", date.getTime());
            hashMap1.put(notif_key_1 + "u", restaurateur.getUid());
            hashMap1.put(notif_key_1 + "c", 1);
            hashMap1.put(notif_key_1 + "p", restaurateur.getProfession());
            hashMap1.put(notif_key_1 + "otp", otp);
            FirebaseDatabase.getInstance().getReference().updateChildren(hashMap1).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(OtherServicesActivity.this, "The job has been scheduled. Please keep checking your order history for status", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(OtherServicesActivity.this, "The job cannot be created", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        });

    }

    public static Date getDate(int year, int month, int day, int hour, int minute) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, month);
        cal.set(Calendar.DAY_OF_MONTH, day);
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    public static String generateDate(int year, int month, int day) {
        String date = day + "";
        switch (day % 10) {
            case 1:
                date += "st";
                break;
            case 2:
                date += "nd";
                break;
            case 3:
                date += "rd";
                break;
            default:
                date += "th";
        }
        switch (month) {
            case 0:
                date += " Jan";
                break;
            case 1:
                date += " Feb";
                break;
            case 2:
                date += " Mar";
                break;
            case 3:
                date += " Apr";
                break;
            case 4:
                date += " May";
                break;
            case 5:
                date += " June";
                break;
            case 6:
                date += " July";
                break;
            case 7:
                date += " Aug";
                break;
            case 8:
                date += " Sept";
                break;
            case 9:
                date += " Oct";
                break;
            case 10:
                date += " Nov";
                break;
            case 11:
                date += " Dec";
                break;
        }
        return date;
    }

    public static String generateTime(int hour, int minute) {
        String time = "";
        boolean am = true;
        if (hour >= 12) {
            am = false;
            hour -= 12;
        }
        if (hour == 0) hour = 12;

        if (hour < 10) time += "0" + hour + ":";
        else time += hour + ":";

        if (minute < 10) time += "0" + minute;
        else time += minute;

        return time + (am ? " AM" : " PM");
    }
}