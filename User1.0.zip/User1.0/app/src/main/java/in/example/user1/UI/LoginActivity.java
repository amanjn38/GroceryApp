package in.example.user1.UI;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Arrays;

import in.example.user1.R;
import static in.example.user1.model.SharedClass.*;

public class LoginActivity extends AppCompatActivity {
    private String email, password, errMsg;
    private CallbackManager mFacebookManager;
    private ProgressDialog progressDialog;
    private FirebaseAuth firebaseAuth;
    private final static int RC_SIGN_IN = 2;
    private GoogleApiClient mGoogleSignInClient;
    private ImageView ivFacebook, ivGoogle;
    private FirebaseUser user;
    private boolean fromRegisterActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ivFacebook = findViewById(R.id.ivFacebook);
        ivGoogle = findViewById(R.id.ivGoogle);
        firebaseAuth = FirebaseAuth.getInstance();
        mFacebookManager = CallbackManager.Factory.create();
        progressDialog = new ProgressDialog(this);

        fromRegisterActivity = getIntent().getBooleanExtra("fromRegisterActivity", false);
        FirebaseAuth auth = FirebaseAuth.getInstance();
        if(!fromRegisterActivity){
            if (auth.getCurrentUser() != null) {
                ROOT_UID = auth.getUid();
                Intent intent = new Intent(LoginActivity.this, NavApp.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        }

        findViewById(R.id.sign_up).setOnClickListener(e -> {
            Intent i = new Intent(this, RegisterActivity.class);
            startActivityForResult(i, 1);
        });

        findViewById(R.id.sign_in).setOnClickListener(e -> {
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Authenticating...");
            if (checkFields()) {
                progressDialog.show();
                auth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(this, task -> {
                            if (task.isSuccessful()) {
                                if (auth.getCurrentUser().isEmailVerified()) {
                                    Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_LONG).show();

                                    ROOT_UID = auth.getUid();
                                    Intent fragment = new Intent(this, NavApp.class);
                                    startActivity(fragment);
                                    progressDialog.dismiss();
                                    finish();
                                } else {
                                    progressDialog.dismiss();
                                    Toast.makeText(LoginActivity.this, "Please verify your email", Toast.LENGTH_LONG).show();
                                }
                            } else {
                                Toast.makeText(LoginActivity.this, "Wrong Username or Password", Toast.LENGTH_LONG).show();
                            }
                        });
            } else {
                Toast.makeText(LoginActivity.this, errMsg, Toast.LENGTH_LONG).show();
                progressDialog.dismiss();
            }
        });
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        mGoogleSignInClient = new GoogleApiClient.Builder(this).enableAutoManage(this, new GoogleApiClient.OnConnectionFailedListener() {
            @Override
            public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
                Toast.makeText(LoginActivity.this, "Connection to google sign in failed", Toast.LENGTH_SHORT).show();

            }
        }).addApi(Auth.GOOGLE_SIGN_IN_API, gso).build();

        FacebookSdk.sdkInitialize(getApplicationContext());

        ivFacebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ivFacebook.setEnabled(false);
                LoginManager.getInstance().logInWithReadPermissions(LoginActivity.this, Arrays.asList("email", "public_profile", "user_friends"));
                LoginManager.getInstance().registerCallback(mFacebookManager, new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        //Toast.makeText(MainActivity.this,"Login successful",Toast.LENGTH_LONG).show();
                        handleFacebookAccessToken(loginResult.getAccessToken());
                    }

                    @Override
                    public void onCancel() {
                        Toast.makeText(LoginActivity.this, "On Cancel", Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onError(FacebookException error) {
                        Log.d("facebookError", error.toString());
                        Toast.makeText(LoginActivity.this, "On Error", Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
        ivGoogle.setOnClickListener(v -> {
            signIn();
        });
    }

    private void signIn() {
        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleSignInClient);
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    public boolean checkFields() {
        email = ((EditText) findViewById(R.id.email)).getText().toString();
        password = ((EditText) findViewById(R.id.password)).getText().toString();

        if (email.trim().length() == 0 || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            errMsg = "Invalid Mail";
            return false;
        }

        if (password.trim().length() == 0) {
            errMsg = "Fill password";
            return false;
        }

        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == 1) {
            Intent fragment = new Intent(this, NavApp.class);
            startActivity(fragment);
            finish();
        }
        if (requestCode == RC_SIGN_IN) {
            progressDialog.setTitle("Google Sign In");
            progressDialog.setMessage("Logging in using your google account");
            progressDialog.setCanceledOnTouchOutside(true);
            progressDialog.show();
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            if (result.isSuccess()) {
                GoogleSignInAccount account = result.getSignInAccount();
                firebaseAuthWithGoogle(account);
                Toast.makeText(LoginActivity.this, "Please wait, while we are getting your auth results", Toast.LENGTH_LONG).show();
            } else {
                progressDialog.dismiss();
                Toast.makeText(LoginActivity.this, "Can't get Auth results", Toast.LENGTH_SHORT).show();
            }
        } else {
            mFacebookManager.onActivityResult(requestCode, resultCode, data);
        }
        if (data != null && resultCode == SIGNUP) {
            Intent fragment = new Intent(this, FragmentManager.class);
            startActivity(fragment);
            finish();
        }


    }

    private void firebaseAuthWithGoogle(GoogleSignInAccount account) {

        AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(LoginActivity.this, "Signed In successfully", Toast.LENGTH_SHORT).show();
                            user = FirebaseAuth.getInstance().getCurrentUser();
                            final boolean[] flag = {false};
                            FirebaseDatabase.getInstance().getReference().child("customers")
                                    .child(user.getUid())
                                    .child("customer_info").addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.hasChild("addr")) {
                                        Log.d("Inside", "True");
                                        progressDialog.dismiss();
                                        Intent intent = new Intent(LoginActivity.this, NavApp.class);
                                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    } else {
                                        progressDialog.dismiss();
                                        Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                                        intent.putExtra("update", true);
                                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                }
                            });
                        } else {
                            //Log.w(TAG, "signInWithCredential:failure", task.getException());
                            String message = task.getException().toString();
                            // SendUserToLoginActivity();
                            Toast.makeText(LoginActivity.this, "Not authenticated " + message, Toast.LENGTH_SHORT).show();
                            progressDialog.dismiss();
                        }
                    }
                });
    }


    private void handleFacebookAccessToken(AccessToken token) {
        //Toast.makeText(MainActivity.this,"Handle facebook handle token" + token,Toast.LENGTH_LONG).show();
        AuthCredential credential = FacebookAuthProvider.getCredential(token.getToken());
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(LoginActivity.this, "Signed In successfully", Toast.LENGTH_SHORT).show();
                            user = FirebaseAuth.getInstance().getCurrentUser();
                            final boolean[] flag = {false};
                            FirebaseDatabase.getInstance().getReference().child("customers")
                                    .child(user.getUid())
                                    .child("customer_info").addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.hasChild("addr")) {
                                        Log.d("Inside", "True");
                                        progressDialog.dismiss();
                                        Intent intent = new Intent(LoginActivity.this, NavApp.class);
                                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    } else {
                                        progressDialog.dismiss();
                                        Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                                        intent.putExtra("update", true);
                                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }
                                }
                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                }
                            });
                            // updateUI();
                        } else {
                            // If sign in fails, display a message to the user.
                            Toast.makeText(LoginActivity.this, "Login failed", Toast.LENGTH_LONG).show();
                            Toast.makeText(LoginActivity.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                            Log.d("Error", task.getException().toString());
                            ivFacebook.setEnabled(true);
                            //updateUI();
                        }

                    }
                });
    }
}