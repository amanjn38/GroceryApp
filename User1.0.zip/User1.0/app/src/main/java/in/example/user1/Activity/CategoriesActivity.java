package in.example.user1.Activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import in.example.user1.R;
import in.example.user1.ViewHolders.DailyOfferViewHolder;
import in.example.user1.model.Restaurateur;
import in.example.user1.models.DishItem;

import static in.example.user1.model.SharedClass.RESTAURATEUR_INFO;

public class CategoriesActivity extends AppCompatActivity {

    private TextView txtbreakfast, txtchocolate, txtbeverages, txtpackaged, txtkitchen, txthomecare, txtpersonal, txt1snacks, next;
    private ImageView breakfast, chocolate, beverages, packaged, kitchen, homecare, personal, snacks;
    private Restaurateur item;
    private String key;
    private long stars;
    private long count;
    FirebaseRecyclerOptions<DishItem> options;
    private SearchView searchView;
    private RecyclerView recyclerView;
    private FirebaseRecyclerAdapter<DishItem, DailyOfferViewHolder> mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private CardView back;
    private Restaurateur restaurateur;
    ArrayList<String> keys = new ArrayList<String>();
    ArrayList<String> names = new ArrayList<String>();
    ArrayList<String> nums = new ArrayList<String>();
    ArrayList<String> prices = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categories);

        //Functions for menu
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        restaurateur = getIntent().getParcelableExtra("res_item");
        key = getIntent().getStringExtra("key");
        RatingBar r = findViewById(R.id.ratingbar);
        back = findViewById(R.id.back);
        next = findViewById(R.id.next);
        txtbreakfast = findViewById(R.id.txtbreakfast);
        chocolate = findViewById(R.id.chocolates);
        beverages = findViewById(R.id.beverages);
        packaged = findViewById(R.id.packaged);
        kitchen = findViewById(R.id.kitchen);
        homecare = findViewById(R.id.homecare);
        breakfast = findViewById(R.id.breakfast);
        personal = findViewById(R.id.personal);
        snacks = findViewById(R.id.snacks);
        txtchocolate = findViewById(R.id.txtchocolates);
        txtbeverages = findViewById(R.id.txtbeverages);
        txtpackaged = findViewById(R.id.txtpackaged);
        txtkitchen = findViewById(R.id.txtkitchen);
        txthomecare = findViewById(R.id.txthome);
        txt1snacks = findViewById(R.id.txtSnacks);
        txtpersonal = findViewById(R.id.txtpersonal);
        searchView = findViewById(R.id.search_view);
        recyclerView = findViewById(R.id.dish_recyclerview);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        txtbeverages.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, TabAppActivity.class);
            intent.putExtra("res_item", restaurateur);
            intent.putExtra("key", this.key);
            intent.putExtra("category", "beverages");
            startActivity(intent);
        });
        beverages.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, TabAppActivity.class);
            intent.putExtra("res_item", restaurateur);
            intent.putExtra("key", this.key);
            intent.putExtra("category", "beverages");
            startActivity(intent);
        });

        txt1snacks.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, TabAppActivity.class);
            intent.putExtra("res_item", restaurateur);
            intent.putExtra("key", this.key);
            intent.putExtra("category", "snacks");
            startActivity(intent);
        });

        snacks.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, TabAppActivity.class);
            intent.putExtra("res_item", restaurateur);
            intent.putExtra("key", this.key);
            intent.putExtra("category", "snacks");
            startActivity(intent);
        });

        txtkitchen.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, TabAppActivity.class);
            intent.putExtra("res_item", restaurateur);
            intent.putExtra("key", this.key);
            intent.putExtra("category", "kitcken");
            startActivity(intent);
        });

        kitchen.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, TabAppActivity.class);
            intent.putExtra("res_item", restaurateur);
            intent.putExtra("key", this.key);
            intent.putExtra("category", "kitchen");
            startActivity(intent);
        });

        txtpackaged.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, TabAppActivity.class);
            intent.putExtra("res_item", restaurateur);
            intent.putExtra("key", this.key);
            intent.putExtra("category", "packaged");
            startActivity(intent);
        });

        packaged.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, TabAppActivity.class);
            intent.putExtra("res_item", restaurateur);
            intent.putExtra("key", this.key);
            intent.putExtra("category", "packaged");
            startActivity(intent);
        });

        txtpersonal.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, TabAppActivity.class);
            intent.putExtra("res_item", restaurateur);
            intent.putExtra("key", this.key);
            intent.putExtra("category", "personal");
            startActivity(intent);
        });

        personal.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, TabAppActivity.class);
            intent.putExtra("res_item", restaurateur);
            intent.putExtra("key", this.key);
            intent.putExtra("category", "personal");
            startActivity(intent);
        });

        txthomecare.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, TabAppActivity.class);
            intent.putExtra("res_item", restaurateur);
            intent.putExtra("key", this.key);
            intent.putExtra("category", "homecare");
            startActivity(intent);
        });

        homecare.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, TabAppActivity.class);
            intent.putExtra("res_item", restaurateur);
            intent.putExtra("key", this.key);
            intent.putExtra("category", "homecare");
            startActivity(intent);
        });

        txtchocolate.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, TabAppActivity.class);
            intent.putExtra("res_item", restaurateur);
            intent.putExtra("key", this.key);
            intent.putExtra("category", "chocolate");
            startActivity(intent);
        });

        chocolate.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, TabAppActivity.class);
            intent.putExtra("res_item", restaurateur);
            intent.putExtra("key", this.key);
            intent.putExtra("category", "chocolate");
            startActivity(intent);
        });

        txtbreakfast.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, TabAppActivity.class);
            intent.putExtra("res_item", restaurateur);
            intent.putExtra("key", this.key);
            intent.putExtra("category", "breakfast");
            startActivity(intent);
        });

        breakfast.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, TabAppActivity.class);
            intent.putExtra("res_item", restaurateur);
            intent.putExtra("key", this.key);
            intent.putExtra("category", "breakfast");
            startActivity(intent);
        });
        //r.setNumStars();
        getIncomingIntent();

//        //Functions for menu
//        getSupportActionBar().setDisplayShowHomeEnabled(true);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        searchView.setOnCloseListener(() -> {
            recyclerView.setVisibility(View.GONE);
            next.setVisibility(View.GONE);
            back.setVisibility(View.VISIBLE);
            return false;
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText.length() == 0) {
                    next.setVisibility(View.VISIBLE);
                    back.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.VISIBLE);
                    options =
                            new FirebaseRecyclerOptions.Builder<DishItem>()
                                    .setQuery(FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO + "/" + key + "/dishes"),
                                            snapshot -> {
                                                DishItem dishItem;
                                                if (snapshot.child("photo").getValue() != null) {
                                                    dishItem = new DishItem(snapshot.child("name").getValue().toString(),
                                                            snapshot.child("desc").getValue().toString(),
                                                            Float.parseFloat(snapshot.child("price").getValue().toString()),
                                                            Integer.parseInt(snapshot.child("quantity").getValue().toString()),
                                                            snapshot.child("photo").getValue().toString());
                                                } else {
                                                    dishItem = new DishItem(snapshot.child("name").getValue().toString(),
                                                            snapshot.child("desc").getValue().toString(),
                                                            Float.parseFloat(snapshot.child("price").getValue().toString()),
                                                            Integer.parseInt(snapshot.child("quantity").getValue().toString()),
                                                            null);
                                                }
                                                return dishItem;
                                            }).build();
                } else {
                    back.setVisibility(View.GONE);
                    next.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.VISIBLE);
                    options = new FirebaseRecyclerOptions.Builder<DishItem>()
                            .setQuery(FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO + "/" + key + "/dishes"), snapshot -> {
                                DishItem dishItem = new DishItem();
                                if (snapshot.child("name").exists() && snapshot.child("name").getValue().toString().toLowerCase().contains(newText.toLowerCase())) {
                                    if (snapshot.child("photo").getValue() != null) {
                                        dishItem = new DishItem(snapshot.child("name").getValue().toString(),
                                                snapshot.child("desc").getValue().toString(),
                                                Float.parseFloat(snapshot.child("price").getValue().toString()),
                                                Integer.parseInt(snapshot.child("quantity").getValue().toString()),
                                                snapshot.child("photo").getValue().toString());
                                    } else {
                                        dishItem = new DishItem(snapshot.child("name").getValue().toString(),
                                                snapshot.child("desc").getValue().toString(),
                                                Float.parseFloat(snapshot.child("price").getValue().toString()),
                                                Integer.parseInt(snapshot.child("quantity").getValue().toString()),
                                                null);
                                    }
                                }
                                return dishItem;
                            }).build();
                }
                mAdapter = new FirebaseRecyclerAdapter<DishItem, DailyOfferViewHolder>(options) {
                    @Override
                    protected void onBindViewHolder(@NonNull DailyOfferViewHolder dailyOfferViewHolder, int i, @NonNull DishItem dishItem) {
                        if (dishItem.getName().equals("")) {
                            dailyOfferViewHolder.itemView.findViewById(R.id.dishItem).setLayoutParams(new FrameLayout.LayoutParams(0, 0));

                        } else {
                            dailyOfferViewHolder.setData(dishItem, i);
                        }

                        TextView numView = dailyOfferViewHolder.getView().findViewById(R.id.dish_num);
                        ConstraintLayout bg2 = dailyOfferViewHolder.getView().findViewById(R.id.bg2);

                        String dish_key = getRef(i).getKey();
                        if (keys.contains(dish_key)) {
                            int pos = keys.indexOf(dish_key);
                            String value_num = nums.get(pos);
                            numView.setText(value_num);
                            CategoriesActivity.this.invalidateOptionsMenu();
                        } else {
                            numView.setText("0");
                            CategoriesActivity.this.invalidateOptionsMenu();
                        }
                        dailyOfferViewHolder.getView().findViewById(R.id.add_dish).setOnClickListener(a -> {
                            Integer num = Integer.parseInt((numView).getText().toString());
                            num++;
                            if (num > dishItem.getQuantity()) {
                                Toast.makeText(dailyOfferViewHolder.getView().getContext(), "Maximum quantity exceeded", Toast.LENGTH_LONG).show();
                            } else if (num > 99) {
                                Toast.makeText(dailyOfferViewHolder.getView().getContext(), "Contact us to get more than this quantity", Toast.LENGTH_LONG).show();
                            } else {
                                numView.setText(num.toString());
                                AddDish(dish_key, dishItem.getName(), Float.toString(dishItem.getPrice()), "add");
                                CategoriesActivity.this.invalidateOptionsMenu();
                            }
                            if (!keys.isEmpty()) {
                                next.setBackgroundColor(Color.parseColor("#5aad54"));
                            }
                        });
                        dailyOfferViewHolder.getView().findViewById(R.id.delete_dish).setOnClickListener(b -> {

                            Integer num = Integer.parseInt((numView).getText().toString());
                            num--;
                            if (num < 0) {
                                Toast.makeText(dailyOfferViewHolder.getView().getContext(), "Please select the right quantity", Toast.LENGTH_LONG).show();
                            } else {
                                numView.setText(num.toString());
                                AddDish(dish_key, dishItem.getName(), Float.toString(dishItem.getPrice()), "remove");
                                CategoriesActivity.this.invalidateOptionsMenu();
                            }
                            if (keys.isEmpty()) {
                                next.setBackgroundColor(Color.parseColor("#c1c1c1"));
                            }
                        });
                    }

                    @NonNull
                    @Override
                    public DailyOfferViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                        final View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dish_item, parent, false);
                        return new DailyOfferViewHolder(view);
                    }
                };
                recyclerView.setAdapter(mAdapter);
                mAdapter.startListening();

                next.setOnClickListener(w -> {
                    if (keys.size() == 0) {
                        Toast.makeText(CategoriesActivity.this, "Inserire un piatto.", Toast.LENGTH_LONG);
                    } else {
                        Intent intent = new Intent(CategoriesActivity.this, ConfirmActivity.class);
                        intent.putExtra("key", key);
                        intent.putExtra("raddr", item.getAddr());
                        intent.putExtra("rname", item.getName());
                        intent.putExtra("photo", item.getPhotoUri());
                        intent.putExtra("uid", item.getUid());
                        intent.putStringArrayListExtra("keys", (ArrayList<String>) keys);
                        intent.putStringArrayListExtra("names", (ArrayList<String>) names);
                        intent.putStringArrayListExtra("prices", (ArrayList<String>) prices);
                        intent.putStringArrayListExtra("nums", (ArrayList<String>) nums);
                        startActivityForResult(intent, 0);
                    }
                });
                return false;
            }
        });

    }

    private void getIncomingIntent() {
        item = (Restaurateur) getIntent().getParcelableExtra("res_item");
        key = getIntent().getStringExtra("key");

        Query query = FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO).child(key).child("stars");
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                RatingBar r = findViewById(R.id.ratingbar);
                TextView number = (TextView) findViewById(R.id.number_rating);
                if (dataSnapshot.exists()) {
                    float s = ((Long) dataSnapshot.child("tot_stars").getValue()).floatValue();
                    float p = ((Long) dataSnapshot.child("tot_review").getValue()).floatValue();
                    if (p != 0) {
                        r.setRating(s / p);
                        number.setText(String.format("%.2f", s / p));
                    } else {
                        r.setRating(0);
                        number.setVisibility(View.GONE);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        setFields(item.getName(), item.getAddr(), item.getPhone(), item.getCuisine(), item.getMail(), item.getOpeningTime(), item.getPhotoUri());
    }

    private void setFields(String name, String addr, String cell, String description, String email, String opening, String img) {
        TextView mname = findViewById(R.id.rest_info_name);
        TextView maddr = findViewById(R.id.rest_info_addr);

        ImageView mimg = findViewById(R.id.imageView);

        mname.setText(name);
        maddr.setText(addr);

        if (!img.equals("null")) {
            Glide.with(getApplicationContext())
                    .load(img)
                    .into(mimg);
        }
    }

    public Restaurateur getItem() {
        return item;
    }

    public String getKey() {
        return key;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (resultCode == 1) {
            finish();
        }
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        if (keys.size() != 0) {
            MenuItem menuItem = (MenuItem) menu.findItem(R.id.action_custom_button);
            TextView cart = menuItem.getActionView().findViewById(R.id.money);
            String snum = getQuantity(nums);
            String tot = calcoloTotale(prices, nums);
            cart.setText(snum + " | " + tot + " ₹");
        }
        super.onPrepareOptionsMenu(menu);
        return true;
    }

    public void AddDish(String key, String name, String price, String mode) {
        if (keys.contains(key) && mode.equals("add")) {
            int i = keys.indexOf(key);
            Integer num = Integer.parseInt(nums.get(i)) + 1;
            nums.set(i, num.toString());
        } else if (keys.contains(key) && mode.equals("remove")) {
            int i = keys.indexOf(key);
            Integer num = Integer.parseInt(nums.get(i)) - 1;
            if (num.equals(0)) {
                keys.remove(i);
                nums.remove(i);
                names.remove(i);
                prices.remove(i);
            } else {
                nums.set(i, num.toString());
            }
        } else {
            keys.add(key);
            nums.add("1");
            names.add(name);
            prices.add(price);
        }
    }


    public String getQuantity(ArrayList<String> nums) {
        int num = 0;
        for (String a : nums) {
            num += Integer.parseInt(a);
        }
        String snum = Integer.toString(num);
        return snum;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.ordering, menu);
        return super.onCreateOptionsMenu(menu);
    }


    private String calcoloTotale(ArrayList<String> prices, ArrayList<String> nums) {
        float tot = 0;
        for (int i = 0; i < prices.size(); i++) {
            float price = Float.parseFloat(prices.get(i));
            float num = Float.parseFloat(nums.get(i));
            tot = tot + (price * num);
        }
        return Float.toString(tot);
    }
}