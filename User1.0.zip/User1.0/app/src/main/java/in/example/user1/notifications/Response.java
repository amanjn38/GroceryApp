package in.example.user1.notifications;

public class Response {

    private String success;
}
