package in.example.user1.Activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import in.example.user1.Adapters.ConfirmRecyclerAdapter;
import in.example.user1.models.OrderCustomerItem;
import in.example.user1.R;
import in.example.user1.model.OrderItem;
import in.example.user1.notifications.APIService;
import in.example.user1.notifications.Client;
import in.example.user1.notifications.Data;
import in.example.user1.notifications.Response;
import in.example.user1.notifications.Sender;
import in.example.user1.notifications.Token;
import retrofit2.Call;
import retrofit2.Callback;

import static android.content.ContentValues.TAG;
import static in.example.user1.model.SharedClass.CUSTOMER_PATH;
import static in.example.user1.model.SharedClass.RESERVATION_PATH;
import static in.example.user1.model.SharedClass.RESTAURATEUR_INFO;
import static in.example.user1.model.SharedClass.ROOT_UID;
import static in.example.user1.model.SharedClass.STATUS_UNKNOWN;
import static in.example.user1.model.SharedClass.TimeOpen;
import static in.example.user1.model.SharedClass.orderToTrack;
import static in.example.user1.model.SharedClass.user;

public class ConfirmActivity extends AppCompatActivity implements PaymentResultListener {

    private String tot, resAddr,resName, resPhoto, uid, option;
    private ArrayList<String> keys;
    private APIService apiService;
    private ArrayList<String> names;
    private ArrayList<String> prices;
    private ArrayList<String> nums;
    private String key;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private String desiredTime = "";
    private int hour, minute;
    private Button desiredTimeButton;
    private Long time;
    private boolean timeOpen_open = false;

    private double total;
    private int totolAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getIncomingIntent();
        apiService = Client.getRetrofit("https://fcm.googleapis.com/").create(APIService.class);

        total = Double.parseDouble(tot);
        totolAmount = (int) total;

        desiredTimeButton = findViewById(R.id.desired_time);
        desiredTimeButton.setOnClickListener(l -> {

                setDesiredTimeDialog();
        });
        findViewById(R.id.confirm_order_button).setOnClickListener(e -> {
            RadioGroup group = findViewById(R.id.radioButton);
            int val = group.getCheckedRadioButtonId();
            if (val == -1) option = "";
            else option = ((RadioButton) findViewById(val)).getText().toString();

            if(option.equals("")){
                Toast.makeText(ConfirmActivity.this,"Select an option to continue",Toast.LENGTH_SHORT).show();
                return;
            }
            if(option.equalsIgnoreCase("Home Delivery")){
                if(desiredTime == null){
                    Toast.makeText(ConfirmActivity.this,"Select a time to continue",Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            AlertDialog dialog = new AlertDialog.Builder(ConfirmActivity.this)
                    .setTitle("Confirmation")
                    .setMessage("Are you sure you want to confirm this order")
                    .setPositiveButton("Yes", (d, i) -> {

                        startPayment();

                    })
                    .setNegativeButton("No", null)
                    .create();
            dialog.show();


        });
    }

    private void getIncomingIntent() {
        keys = getIntent().getStringArrayListExtra("keys");
        names = getIntent().getStringArrayListExtra("names");
        prices = getIntent().getStringArrayListExtra("prices");
        nums = getIntent().getStringArrayListExtra("nums");
        key = getIntent().getStringExtra("key");
        resAddr = getIntent().getStringExtra("raddr");
        resPhoto = getIntent().getStringExtra("photo");
        resName = getIntent().getStringExtra("rname");
        uid = getIntent().getStringExtra("uid");

        recyclerView = findViewById(R.id.dish_conf_recyclerview);
        mAdapter = new ConfirmRecyclerAdapter(this, names, prices, nums, ConfirmActivity.this);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setAdapter(mAdapter);
        recyclerView.setLayoutManager(layoutManager);

        updatePrice();
    }

    private String calcoloTotale(ArrayList<String> prices, ArrayList<String> nums) {
        float tot = 0;
        for (int i = 0; i < prices.size(); i++) {
            float price = Float.parseFloat(prices.get(i));
            float num = Float.parseFloat(nums.get(i));
            tot = tot + (price * num);
        }
        return Float.toString(tot);
    }

    private String[] setTimeValue() {
        String[] cent = new String[100];
        for (int i = 0; i < 100; i++) {
            if (i < 10) {
                cent[i] = "0" + i;
            } else {
                cent[i] = "" + i;
            }
        }
        return cent;
    }

    private void setDesiredTimeDialog() {
        timeOpen_open = true;
        Calendar calendar = Calendar.getInstance();
        TimePickerDialog mTimePicker;
        mTimePicker = new TimePickerDialog(ConfirmActivity.this, (timePicker, selectedHour, selectedMinute) -> {
            timeOpen_open = false;
            this.hour = selectedHour;
            this.minute = selectedMinute;
            desiredTimeButton.setText(generateTime(selectedHour, selectedMinute));
            desiredTime = generateTime(selectedHour, selectedMinute);
            time = getDate(selectedHour, selectedMinute);
        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false);//Yes 24 hour time
        mTimePicker.setTitle("Select Time");
        mTimePicker.show();
    }

    private Long getDate(int hour, int min) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, min);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        Date date = cal.getTime();
        if (cal.before(Calendar.getInstance())) {
            cal.set(Calendar.DATE, cal.get(Calendar.DATE) + 1);
            date = cal.getTime();
        }
        return date.getTime();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {

            this.finish();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();

    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);

        savedInstanceState.putBoolean(TimeOpen, timeOpen_open);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {

        super.onRestoreInstanceState(savedInstanceState);
        if (savedInstanceState.getBoolean(TimeOpen))
            setDesiredTimeDialog();
    }

    public void updatePrice() {
        tot = calcoloTotale(prices, nums);
        TextView totale = findViewById(R.id.total);
        totale.setText(tot + " ₹");
    }

    public static String generateTime(int hour, int minute) {
        String time = "";
        boolean am = true;
        if (hour >= 12) {
            am = false;
            hour -= 12;
        }
        if (hour == 0) hour = 12;

        if (hour < 10) time += "0" + hour + ":";
        else time += hour + ":";

        if (minute < 10) time += "0" + minute;
        else time += minute;

        return time;
    }

    private void sendNotification(String uid, String s, String s1) {
        DatabaseReference allTokens = FirebaseDatabase.getInstance().getReference("Tokens");
        Query query = allTokens.orderByKey().equalTo(uid);
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot ds : snapshot.getChildren()) {
                    Token token = ds.getValue(Token.class);
                    Data data = new Data(FirebaseAuth.getInstance().getCurrentUser().getUid(), s, s1, uid, R.drawable.time_icon);

                    Sender sender = new Sender(data, token.getToken());
                    apiService.sendNotification(sender)
                            .enqueue(new Callback<Response>() {
                                @Override
                                public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                                    Toast.makeText(ConfirmActivity.this, "Test Successful" + response.message(), Toast.LENGTH_LONG).show();
                                }

                                @Override
                                public void onFailure(Call<Response> call, Throwable t) {

                                }
                            });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void startPayment() {
        /**
         * Instantiate Checkout
         */
        Checkout checkout = new Checkout();

        /**
         * Set your logo here
         */
//        checkout.setImage(R.drawable.logo1);

        /**
         * Reference to current activity
         */
        final Activity activity = this;

        /**
         * Pass your payment options to the Razorpay Checkout as a JSONObject
         */
        try {
            JSONObject options = new JSONObject();

            /**
             * Merchant Name
             * eg: ACME Corp || HasGeek etc.
             */
            options.put("name", "Dete");

            /**
             * Description can be anything
             * eg: Reference No. #123123 - This order number is passed by you for your internal reference. This is not the `razorpay_order_id`.
             *     Invoice Payment
             *     etc.
             */
            options.put("description", "Delivery Order");
            options.put("currency", "INR");

            /**
             * Amount is always passed in currency subunits
             * Eg: "500" = INR 5.00
             */
            options.put("amount", String.valueOf(totolAmount*100));

            checkout.open(activity, options);
        } catch(Exception e) {
            Log.e(TAG, "Error in starting Razorpay Checkout", e);
        }
    }


    @Override
    public void onPaymentSuccess(String s) {

        RadioGroup group = findViewById(R.id.radioButton);
        int val = group.getCheckedRadioButtonId();
        if (val == -1) option = "";
        else option = ((RadioButton) findViewById(val)).getText().toString();

        if (option.equalsIgnoreCase("Home Delivery")) {

            Log.i("Home Delivery","Entered");
            if(desiredTime == null){
                Toast.makeText(ConfirmActivity.this,"Select the time",Toast.LENGTH_SHORT).show();
                return;
            }

            if (desiredTime.trim().length() > 0) {
                DatabaseReference myRef1 = FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO + "/" +
                        key + RESERVATION_PATH);

                DatabaseReference myRef2 = FirebaseDatabase.getInstance().getReference(CUSTOMER_PATH + "/" + ROOT_UID).child("orders");
                HashMap<String, Object> order = new HashMap<>();
                HashMap<String, Integer> dishes = new HashMap<>();
                for (String key : keys) {
                    dishes.put(key, Integer.parseInt(nums.get(keys.indexOf(key))));
                }
                String keyOrder = myRef2.push().getKey();
                order.put(keyOrder, new OrderCustomerItem(key, user.getAddr(), tot, dishes, time, Long.MAX_VALUE - time, STATUS_UNKNOWN, true, 0,s));
                myRef2.updateChildren(order);

                HashMap<String, Integer> piatti = new HashMap<>();
                for (String name : names) {
                    piatti.put(name, Integer.parseInt(nums.get(name.indexOf(name))));
                }
                HashMap<String, Object> orderMap = new HashMap<>();
                orderMap.put(keyOrder, new OrderItem(ROOT_UID, user.getAddr(), tot, STATUS_UNKNOWN, piatti, time, 0,s));
                myRef1.updateChildren(orderMap);

                if (orderToTrack == null) {
                    orderToTrack = new HashMap<>();
                }
                orderToTrack.put(keyOrder, STATUS_UNKNOWN);

                sendNotification(uid, user.getName() + "has requested a new job", "Please respond to the job accordingly");

                Toast.makeText(this, "Order confirmed", Toast.LENGTH_LONG).show();
                setResult(1);
                finish();
            } else
                Toast.makeText(this, "Please select desired time", Toast.LENGTH_LONG).show();
        } else if (option.equalsIgnoreCase("Pickup")) {
            DatabaseReference myRef1 = FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO + "/" +
                    key + RESERVATION_PATH);

            DatabaseReference myRef2 = FirebaseDatabase.getInstance().getReference(CUSTOMER_PATH + "/" + ROOT_UID).child("orders");
            HashMap<String, Object> order = new HashMap<>();
            HashMap<String, Integer> dishes = new HashMap<>();
            for (String key : keys) {
                dishes.put(key, Integer.parseInt(nums.get(keys.indexOf(key))));
            }
            String keyOrder = myRef2.push().getKey();
            order.put(keyOrder, new OrderCustomerItem(key, user.getAddr(), tot, dishes, time, Long.MAX_VALUE - time, STATUS_UNKNOWN, true, 1, s));
            myRef2.updateChildren(order);

            HashMap<String, Integer> piatti = new HashMap<>();
            for (String name : names) {
                piatti.put(name, Integer.parseInt(nums.get(name.indexOf(name))));
            }
            HashMap<String, Object> orderMap = new HashMap<>();
            orderMap.put(keyOrder, new OrderItem(ROOT_UID, user.getAddr(), tot, STATUS_UNKNOWN, piatti, time, 1,s));
            myRef1.updateChildren(orderMap);

            if (orderToTrack == null) {
                orderToTrack = new HashMap<>();
            }
            orderToTrack.put(keyOrder, STATUS_UNKNOWN);

            sendNotification(uid, user.getName() + "has requested a new job", "Please respond to the job accordingly");

            Toast.makeText(this, "Order confirmed", Toast.LENGTH_LONG).show();
            setResult(1);
            finish();
        }
    }

    @Override
    public void onPaymentError(int i, String s) {
        Toast.makeText(ConfirmActivity.this,"Payment failed",Toast.LENGTH_SHORT).show();
        finish();
    }
}

