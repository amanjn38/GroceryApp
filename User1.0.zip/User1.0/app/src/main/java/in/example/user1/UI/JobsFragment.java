package in.example.user1.UI;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import in.example.user1.R;
import in.example.user1.model.Jobs;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link JobsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class JobsFragment extends Fragment {

    private OnFragmentInteractionListener mListener;
    private JobsAdapter adapter;


    private RecyclerView recyclerView;
    private ArrayList<Jobs> arrayList;
    private ArrayList<String> stringArrayList;

    public JobsFragment() {
        // Required empty public constructor
    }

    public static JobsFragment newInstance(String param1, String param2) {
        JobsFragment fragment = new JobsFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        arrayList = new ArrayList<>();
        stringArrayList = new ArrayList<>();
        View v = inflater.inflate(R.layout.fragment_jobs, container, false);
        recyclerView = v.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        FirebaseDatabase.getInstance().getReference("user_notifications").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("jobs").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        if (dataSnapshot.child("c").getValue().toString().equalsIgnoreCase("2")
                        || dataSnapshot.child("c").getValue().toString().equalsIgnoreCase("5")) {
                            Jobs jobs = new Jobs();
                            Timestamp t = new Timestamp((Long.parseLong(dataSnapshot.child("t").getValue().toString()) / 1000), 0);
                            jobs.setT(t);
                            jobs.setP(dataSnapshot.child("p").getValue().toString());
                            jobs.setOtp(Integer.parseInt(dataSnapshot.child("otp").getValue().toString()));
                            jobs.setC(Integer.parseInt(dataSnapshot.child("c").getValue().toString()));
                            jobs.setU(dataSnapshot.child("u").getValue().toString());
                            arrayList.add(jobs);
                            stringArrayList.add(dataSnapshot.getKey());

                        }
                    }
                    Log.d("jobs", arrayList.get(0).getU().toString());
                    adapter = new JobsAdapter(getActivity(), arrayList, stringArrayList);
                    recyclerView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        return v;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}