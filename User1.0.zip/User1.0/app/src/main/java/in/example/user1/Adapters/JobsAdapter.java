package in.example.user1.Adapters;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import in.example.user1.Activity.RatingActivity;
import in.example.user1.R;
import in.example.user1.model.Jobs;
import in.example.user1.model.ReviewItem;

import static in.example.user1.model.SharedClass.RESTAURATEUR_INFO;

public class JobsAdapter extends RecyclerView.Adapter<JobsAdapter.ViewHolder> {

    private Context context;
    private ArrayList<Jobs> arrayList;
    private ArrayList<String> stringArrayList;
    View view;

    public JobsAdapter(Context context, ArrayList<Jobs> arrayList, ArrayList<String> stringArrayList) {
        this.context = context;
        this.arrayList = arrayList;
        this.stringArrayList = stringArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        switch (viewType) {
            case 1:
                return new JobRequest(LayoutInflater.from(parent.getContext()).inflate(R.layout.job_request_row, parent, false));
            case 2:
                return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.rejected_job_layout, parent, false));
        }
        return new JobRequest(LayoutInflater.from(parent.getContext()).inflate(R.layout.job_request_row, parent, false));

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Log.d("jobs", arrayList.get(position).toString());
        final Jobs jobs = arrayList.get(position);
        Log.d("jobsadapter", arrayList.get(position).toString());

        String key = stringArrayList.get(position);
        Date iDate = jobs.getT().toDate();

        SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
        DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

        String dateString = dateFormatter.format(iDate);
        String timeString = timeFormat.format(iDate);

        holder.notif_day.setText(dateString);
        holder.notif_time.setText(timeString);

        Query getGlobalRating = FirebaseDatabase.getInstance().getReference().child(RESTAURATEUR_INFO + "/" + jobs.getU()).child("review");
        getGlobalRating.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    float totRating = 0;
                    long nReviews = dataSnapshot.getChildrenCount();

                    for (DataSnapshot d : dataSnapshot.getChildren()) {
                        Log.d("aman", "working");
                        ReviewItem reviewItem = d.getValue(ReviewItem.class);
                        totRating += reviewItem.getStars();
                    }
                    Log.d("rating", Float.toString(totRating));

                    totRating = totRating / nReviews;
                    holder.ratingBar.setRating(totRating);
                    holder.rating.setText(Float.toString(totRating));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w("PAGER ADAPTER PROFILE", "Failed to read value.", databaseError.toException());
            }
        });

        switch (holder.getItemViewType()) {
            case 1:
                final String[] phone = new String[1];
                final String[] photoPath = new String[1];
                final String[] name = new String[1];
                FirebaseFirestore.getInstance().collection("Home Enterpreneurs").document(jobs.getU()).get()
                        .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    DocumentSnapshot d = task.getResult();
                                    holder.notif_msg.setText("Job Request Details");
                                    ((JobRequest) holder).address.setText(d.get("add").toString());
                                    phone[0] = d.get("ph").toString();

                                    name[0] = d.get("n").toString();
                                    ((JobRequest) holder).phone.setText(phone[0]);

                                    if (d.contains("pu")) {
                                        photoPath[0] = d.get("pu").toString();
                                        Glide.with(context)
                                                .load(d.get("pu").toString())
                                                .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                                                .placeholder(R.drawable.ic_male)
                                                .dontAnimate()
                                                .centerInside()
                                                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                                .into(holder.notifDp);
                                    } else {
                                        Glide.with(context)
                                                .load(R.drawable.ic_male)
                                                .placeholder(R.drawable.ic_male)
                                                .dontAnimate()
                                                .centerInside()
                                                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                                .into(holder.notifDp);
                                    }
                                }
                            }
                        });
                holder.response.setText("Accepted");

                if (jobs.getC() == 2) {
                    ((JobRequest) holder).call.setOnClickListener(v -> {
                        Intent callIntent = new Intent(Intent.ACTION_CALL);
                        Log.d("phone", phone[0].toString());
                        callIntent.setData(Uri.parse("tel:" + "+91" + phone[0]));//change the number
                        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                            // TODO: Consider calling
                            //    ActivityCompat#requestPermissions
                            // here to request the missing permissions, and then overriding
                            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                            //                                          int[] grantResults)
                            // to handle the case where the user grants the permission. See the documentation
                            // for ActivityCompat#requestPermissions for more details.
                            return;
                        }
                        context.startActivity(callIntent);
                    });
                    ((JobRequest) holder).btnCompleted.setOnClickListener(v -> {
                        AlertDialog dialog = new AlertDialog.Builder(context)
                                .setMessage("By clicking you assure that the job is completed. Please rate the worker")
                                .setPositiveButton("Yes", (d, i) -> {
                                    FirebaseDatabase.getInstance().getReference("notifications").child(jobs.getU()).child("jobs").child(key).child("c").setValue(3);
                                    FirebaseDatabase.getInstance().getReference("user_notifications").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("jobs").child(key).child("c").setValue(3);
                                })
                                .setNegativeButton("No", null)
                                .create();
                        dialog.show();
                    });
                    ((JobRequest) holder).issue.setText(jobs.getIssue());
                    ((JobRequest) holder).btnReview.setVisibility(View.GONE);
                } else if (jobs.getC() == 3) {
                    ((JobRequest) holder).btnReview.setOnClickListener(v -> {
                        Intent intent = new Intent(context, RatingActivity.class);
                        intent.putExtra("orderId", stringArrayList.get(position).toString());
                        intent.putExtra("workerUID", arrayList.get(position).getU());
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        context.startActivity(intent);
                    });
                    ((JobRequest) holder).issue.setText(jobs.getIssue());
                    ((JobRequest) holder).btnCompleted.setVisibility(View.GONE);
                    ((JobRequest) holder).phone.setVisibility(View.GONE);
                    ((JobRequest) holder).call.setVisibility(View.GONE);
                    ((JobRequest) holder).holderPhone.setVisibility(View.GONE);
                    holder.response.setText("Completed and Not Rated");

                } else if (jobs.getC() == 4) {
                    ((JobRequest) holder).btnReview.setVisibility(View.GONE);
                    ((JobRequest) holder).btnCompleted.setVisibility(View.GONE);
                    ((JobRequest) holder).call.setVisibility(View.GONE);
                    ((JobRequest) holder).phone.setVisibility(View.GONE);
                    ((JobRequest) holder).address.setVisibility(View.GONE);
                    ((JobRequest) holder).holderPhone.setVisibility(View.GONE);
                    ((JobRequest) holder).holderAddr.setVisibility(View.GONE);
                    ((JobRequest) holder).issue.setText(jobs.getIssue());

                    holder.response.setText("Completed and Rated");
                }
                break;
            case 2:
                holder.btnCancel.setVisibility(View.INVISIBLE);
                FirebaseFirestore.getInstance().collection("Home Enterpreneurs").document(jobs.getU()).get()
                        .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    DocumentSnapshot d = task.getResult();
                                    holder.notif_msg.setText("Job Request Details");
                                    if (d.contains("pu")) {
                                        Glide.with(context)
                                                .load(d.get("pu").toString())
                                                .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                                                .placeholder(R.drawable.ic_male)
                                                .dontAnimate()
                                                .centerInside()
                                                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                                .into(holder.notifDp);
                                    } else {
                                        Glide.with(context)
                                                .load(R.drawable.person)
                                                .placeholder(R.drawable.ic_male)
                                                .dontAnimate()
                                                .centerInside()
                                                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                                .into(holder.notifDp);
                                    }
                                }
                            }
                        });
                holder.response.setText("Rejected");
                break;
        }

    }

    public View getView() {
        return view;
    }


    @Override
    public int getItemViewType(int position) {
        if (arrayList.get(position).getC() == 2 || arrayList.get(position).getC() == 3 || arrayList.get(position).getC() == 4) {
            return 1;
        } else if (arrayList.get(position).getC() == 5) {
            return 2;
        }
        return 1;
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView notifDp;
        private TextView notif_msg, notif_day, notif_time, response;
        private ConstraintLayout bgCard;
        private RatingBar ratingBar;
        private TextView rating;
        private Button btnCancel;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            view = itemView;
            btnCancel = itemView.findViewById(R.id.btnCancel);
            rating = itemView.findViewById(R.id.rating);
            ratingBar = itemView.findViewById(R.id.ratingBaritem);
            notifDp = itemView.findViewById(R.id.notifDp);
            notif_msg = itemView.findViewById(R.id.notif_msg);
            notif_day = itemView.findViewById(R.id.notif_day);
            notif_time = itemView.findViewById(R.id.notif_time);
            bgCard = itemView.findViewById(R.id.bgCard);
            response = itemView.findViewById(R.id.response);
        }
    }

    class JobRequest extends ViewHolder {
        private TextView address, phone, holderAddr, holderPhone, issue;
        private ImageView call;
        private Button btnCompleted, btnReview;

        public JobRequest(@NonNull View itemView) {
            super(itemView);
            view = itemView;
            issue = itemView.findViewById(R.id.issue);
            call = itemView.findViewById(R.id.call);
            address = itemView.findViewById(R.id.address);
            phone = itemView.findViewById(R.id.phone);
            btnCompleted = itemView.findViewById(R.id.btnCompleted);
            btnReview = itemView.findViewById(R.id.btnReview);
            holderAddr = itemView.findViewById(R.id.holderAddr);
            holderPhone = itemView.findViewById(R.id.holderPhone);
        }
    }
}


