package in.example.user1.ViewHolders;

import android.util.Log;
import android.view.View;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import java.io.InputStream;

import in.example.user1.models.DishItem;
import in.example.user1.R;

public class DailyOfferViewHolder extends RecyclerView.ViewHolder implements Filterable {
    private ImageView dishPhoto;
    private TextView dishName, dishDesc, dishPrice, dishQuantity;
    private View view;


    public DailyOfferViewHolder(View itemView) {
        super(itemView);
        view = itemView;
        dishName = itemView.findViewById(R.id.dish_name);
        dishDesc = itemView.findViewById(R.id.dish_desc);
        dishPrice = itemView.findViewById(R.id.dish_price);
        dishPhoto = itemView.findViewById(R.id.dish_image);

    }

    public void setData(DishItem current, int position) {
        InputStream inputStream = null;
        Log.d("price", current.getPrice()+"");
        if(!(Float.toString(current.getPrice()).equalsIgnoreCase("-1.0"))){
            this.dishName.setText(current.getName());
            this.dishDesc.setText(current.getDesc());
            this.dishPrice.setText(current.getPrice() + " ₹");
            if (current.getPhotoUri() != null) {
                Glide.with(view.getContext()).load(current.getPhotoUri()).override(80,80).into(dishPhoto);
            }
        }

    }

    public View getView() {
        return view;
    }

    @Override
    public Filter getFilter() {
        return null;
    }
}
