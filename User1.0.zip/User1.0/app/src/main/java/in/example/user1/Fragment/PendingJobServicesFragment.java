package in.example.user1.Fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import in.example.user1.Adapters.JobsAdapter;
import in.example.user1.Adapters.PendingJobAdapter;
import in.example.user1.R;
import in.example.user1.model.Jobs;
import in.example.user1.notifications.Token;

public class PendingJobServicesFragment extends Fragment {
    private PendingJobServicesFragment.OnFragmentInteractionListener mListener;

    private PendingJobAdapter adapter;
    private RecyclerView recyclerView;
    private ArrayList<Jobs> arrayList;
    private ArrayList<String> stringArrayList;

    public PendingJobServicesFragment() {
        // Required empty public constructor
    }

    public static PendingJobServicesFragment newInstance() {
        PendingJobServicesFragment fragment = new PendingJobServicesFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_pending_job_services, container, false);
        arrayList = new ArrayList<>();
        stringArrayList = new ArrayList<>();
        recyclerView = v.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        FirebaseDatabase.getInstance().getReference("user_notifications").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("jobs").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        if (dataSnapshot.child("c").getValue().toString().equalsIgnoreCase("1")) {
                            Jobs jobs = new Jobs();
                            Timestamp t = new Timestamp((Long.parseLong(dataSnapshot.child("t").getValue().toString()) / 1000), 0);
                            jobs.setT(t);
                            jobs.setP(dataSnapshot.child("p").getValue().toString());
                            jobs.setOtp(Integer.parseInt(dataSnapshot.child("otp").getValue().toString()));
                            jobs.setC(Integer.parseInt(dataSnapshot.child("c").getValue().toString()));
                            jobs.setU(dataSnapshot.child("u").getValue().toString());
                            jobs.setIssue(dataSnapshot.child("issue").getValue().toString());
                            arrayList.add(jobs);
                            stringArrayList.add(dataSnapshot.getKey());
                            Log.d("array", jobs.toString());
                        }
                    }
                    adapter = new PendingJobAdapter(getActivity(), arrayList, stringArrayList);
                    recyclerView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        return v;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof PendingJobServicesFragment.OnFragmentInteractionListener) {
            mListener = (PendingJobServicesFragment.OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    public void updateToken(String token) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Tokens");
        Token mToken = new Token(token);
        ref.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(mToken);
    }

    @Override
    public void onPause() {
        super.onPause();
    }
}