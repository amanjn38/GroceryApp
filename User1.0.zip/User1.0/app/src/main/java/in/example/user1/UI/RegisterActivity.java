package in.example.user1.UI;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.icu.text.SimpleDateFormat;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import in.example.user1.R;
import in.example.user1.model.User;

import static in.example.user1.model.SharedClass.CUSTOMER_PATH;
import static in.example.user1.model.SharedClass.CameraOpen;
import static in.example.user1.model.SharedClass.Mail;
import static in.example.user1.model.SharedClass.Name;
import static in.example.user1.model.SharedClass.PERMISSION_GALLERY_REQUEST;
import static in.example.user1.model.SharedClass.Phone;
import static in.example.user1.model.SharedClass.Photo;
import static in.example.user1.model.SharedClass.ROOT_UID;


public class RegisterActivity extends AppCompatActivity {
    private boolean dialog_open = false;

    private String name, mail, phone, currentPhotoPath, psw, psw_confirm, address, error_msg;
    private boolean update;
    private EditText address1;
    private double latitude, longitude;
    private static int AUTOCOMPLETE_PLACES = 502;
    private TextView sign_in;
    private FirebaseDatabase database;
    private LatLng source;
    public static int AUTOCOMPLETE_SOURCE = 180;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        database = FirebaseDatabase.getInstance();
        FirebaseAuth auth = FirebaseAuth.getInstance();

        update = getIntent().getBooleanExtra("update", false);
        Log.d("UPDATEI", String.valueOf(update));
        Places.initialize(RegisterActivity.this, "AIzaSyAzScFoOmgLSQsVPK7QT4btN9wIhjoP4qM");
        List<Place.Field> fields = Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG);


        sign_in = findViewById(R.id.sign_in);
        sign_in.setOnClickListener(v -> {
            Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
        address1 = findViewById(R.id.address);
        address1.setOnClickListener(view ->
                startActivityForResult(new Intent(RegisterActivity.this, MapPickerActivity.class), AUTOCOMPLETE_SOURCE));

        if (update) {
            findViewById(R.id.mail).setVisibility(View.GONE);
            findViewById(R.id.psw).setVisibility(View.GONE);
        }

        ImageView confirm_reg = findViewById(R.id.sign_up);

        confirm_reg.setOnClickListener(e -> {
            if (checkFields()) {
                Log.d("Inside", "Working");

                if (!update) {
                    auth.createUserWithEmailAndPassword(mail, psw).addOnCompleteListener(this, task -> {
                        if (task.isSuccessful()) {
                            auth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(RegisterActivity.this, "Registered successfully, Please verify your email.", Toast.LENGTH_LONG).show();
                                        ROOT_UID = auth.getUid();
                                        storeDatabase();
                                        Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                                        intent.putExtra("fromRegisterActivity", true);
                                        startActivity(intent);

                                    } else {
                                        Log.d("email", "email");
                                        Toast.makeText(RegisterActivity.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                        } else {
                            Toast.makeText(RegisterActivity.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }

                    });
                } else if (update) {
                    storeDatabase();
                }
            }
        });
        findViewById(R.id.img_profile).setOnClickListener(e -> editPhoto());
    }

    private boolean Validate() {
        Log.d("Loop1", "True");
        name = ((EditText) findViewById(R.id.name)).getText().toString();
        phone = ((EditText) findViewById(R.id.time_text)).getText().toString();
        address = ((EditText) findViewById(R.id.address)).getText().toString();

        if (name.trim().length() == 0) {
            error_msg = "Fill Name";
            return false;
        }

        if (phone.trim().length() != 10) {
            error_msg = "Invalid Phone Number";
            return false;
        }
        if (address.trim().length() == 0) {
            error_msg = "Fill Address";
            return false;
        }
        return true;
    }

    private void storeDatabase() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        DatabaseReference myRef;
        if (update) {
            myRef = database.getReference(CUSTOMER_PATH + "/" + FirebaseAuth.getInstance().getCurrentUser().getUid());

        } else {
            myRef = database.getReference(CUSTOMER_PATH + "/" + ROOT_UID);

        }
        Log.d("Inside", "Working");
        progressDialog.setTitle("Creating profile...");
        progressDialog.show();
        HashMap<String, Object> infor = new HashMap<>();

        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        String strmail;
        if (update) {
            strmail = FirebaseAuth.getInstance().getCurrentUser().getEmail();
        } else {
            strmail = ((EditText) findViewById(R.id.mail)).getText().toString();
            String strpsw = ((EditText) findViewById(R.id.psw)).getText().toString();
            infor.put("p", strpsw);

        }
        String strname = ((EditText) findViewById(R.id.name)).getText().toString();
        String straddr = ((EditText) findViewById(R.id.address)).getText().toString();
        String strphone = ((EditText) findViewById(R.id.time_text)).getText().toString();

        infor.put("e", strmail);
        infor.put("n", strname);
        infor.put("add", straddr);
        infor.put("ph", strphone);
        infor.put("lt", latitude);
        infor.put("lo", longitude);
        if (currentPhotoPath != null) {
            infor.put("pu", currentPhotoPath);
        }
        infor.put("uid", uid);
        FirebaseFirestore.getInstance().collection("customers").document(uid).set(infor).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(RegisterActivity.this, "Your data has been stored successfully", Toast.LENGTH_LONG).show();
                }
            }
        });
        if (currentPhotoPath != null) {
            Uri url = Uri.fromFile(new File(currentPhotoPath));
            StorageReference storageReference = FirebaseStorage.getInstance().getReference();
            StorageReference ref = storageReference.child("images/" + UUID.randomUUID().toString());
            ref.putFile(url).continueWithTask(task -> {
                if (!task.isSuccessful()) {
                    throw task.getException();
                }
                return ref.getDownloadUrl();
            }).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Uri downUri = task.getResult();
                    Log.d("URL", "onComplete: Url: " + downUri.toString());
                    Map<String, Object> new_user = new HashMap<>();
                    String email1;
                    if (update) {
                        email1 = FirebaseAuth.getInstance().getCurrentUser().getEmail();
                        new_user.put("customer_info", new User("amanjn38", name
                                , email1, phone, address, downUri.toString()));
                    } else {
                        new_user.put("customer_info", new User("amanjn38", name
                                , mail, phone, address, downUri.toString()));
                    }

                    myRef.updateChildren(new_user);

                    Intent i = new Intent();
                    setResult(1, i);

                    progressDialog.dismiss();
                    finish();
                }
            }).addOnFailureListener(task -> {
                Log.d("FAILURE", task.getMessage());
            });
        } else {
            Map<String, Object> new_user = new HashMap<String, Object>();

            String email1;
            if (update) {
                email1 = FirebaseAuth.getInstance().getCurrentUser().getEmail();
                new_user.put("customer_info", new User("amanjn38", name
                        , email1, phone, address, null));
            } else {
                new_user.put("customer_info", new User("amanjn38", name
                        , mail, phone, address, null));
            }
            myRef.updateChildren(new_user);

            Intent i = new Intent();
            setResult(1, i);

            progressDialog.dismiss();
            finish();
        }
    }

    private void editPhoto() {
        AlertDialog alertDialog = new AlertDialog.Builder(RegisterActivity.this, R.style.AppTheme_AlertDialogStyle).create();
        LayoutInflater factory = LayoutInflater.from(RegisterActivity.this);
        final View view = factory.inflate(R.layout.custom_dialog, null);

        dialog_open = true;

        alertDialog.setOnCancelListener(dialog -> {
            dialog_open = false;
            alertDialog.dismiss();
        });

        view.findViewById(R.id.camera).setOnClickListener(c -> {
            cameraIntent();
            dialog_open = false;
            alertDialog.dismiss();
        });
        view.findViewById(R.id.gallery).setOnClickListener(g -> {
            galleryIntent();
            dialog_open = false;
            alertDialog.dismiss();
        });
        view.findViewById(R.id.button_camera).setOnClickListener(v -> {
            cameraIntent();
            dialog_open = false;
            alertDialog.dismiss();
        });

        view.findViewById(R.id.button_gallery).setOnClickListener(r -> {
            galleryIntent();
            dialog_open = false;
            alertDialog.dismiss();
        });
        alertDialog.setView(view);
        alertDialog.show();

    }

    private void cameraIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            File photoFile = createImageFile();

            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "com.mad.customer.fileprovider",
                        photoFile);

                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, 2);
            }
        }
    }

    private void galleryIntent() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    PERMISSION_GALLERY_REQUEST);
        } else {
            Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
            photoPickerIntent.setType("image/*");
            startActivityForResult(photoPickerIntent, 1);
        }
    }

    private boolean checkFields() {
        Log.d("Loop2", "False");

        name = ((EditText) findViewById(R.id.name)).getText().toString();
        mail = ((EditText) findViewById(R.id.mail)).getText().toString();
        phone = ((EditText) findViewById(R.id.time_text)).getText().toString();
        psw = ((EditText) findViewById(R.id.psw)).getText().toString();
        address = ((EditText) findViewById(R.id.address)).getText().toString();

        if (!update) {
            if (mail.trim().length() == 0 || !android.util.Patterns.EMAIL_ADDRESS.matcher(mail).matches()) {
                error_msg = "Invalid e-mail";
                return false;
            }
            if (psw.trim().length() == 0) {
                error_msg = "Fill Password";
                return false;
            }
        }

        if (address.trim().length() == 0) {
            error_msg = "Fill Address";
            return false;
        }
        if (name.trim().length() == 0) {
            error_msg = "Fill name";
            return false;
        }

        if (phone.trim().length() != 10) {
            error_msg = "Invalid phone number";
            return false;
        }

        return true;
    }

    private File createImageFile() {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "IMG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = new File(storageDir + File.separator +
                imageFileName + /* prefix */
                ".jpg"
        );

        // Save a file: path for use with ACTION_VIEW intents
        currentPhotoPath = image.getAbsolutePath();

        return image;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        if (requestCode == PERMISSION_GALLERY_REQUEST) {// If request is cancelled, the result arrays are empty.
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("Permission Run Time: ", "Obtained");

                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                photoPickerIntent.setType("image/*");
                startActivityForResult(photoPickerIntent, 1);
            } else {
                Log.d("Permission Run Time: ", "Denied");

                Toast.makeText(getApplicationContext(), "Access to media files denied", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if ((requestCode == 1) && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();

            String[] filePathColumn = {MediaStore.Images.Media.DATA};

            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();

            currentPhotoPath = picturePath;
        }

        if ((requestCode == 1 || requestCode == 2) && resultCode == RESULT_OK) {
            Glide.with(getApplicationContext()).load(currentPhotoPath).into((ImageView) findViewById(R.id.img_profile));
        }

        if (requestCode == AUTOCOMPLETE_SOURCE) {
            if (resultCode == RESULT_OK) {
                Log.d("name", data.getStringExtra("name"));
                address1.setText(data.getStringExtra("name"));
                source = data.getParcelableExtra("location");
                latitude = source.latitude;
                longitude = source.longitude;
            }
        }
        if (currentPhotoPath != null) {
            Glide.with(Objects.requireNonNull(this))
                    .load(currentPhotoPath)
                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                    .into((ImageView) findViewById(R.id.img_profile));
        } else {
            Glide.with(Objects.requireNonNull(this))
                    .load(R.drawable.restaurant_home)
                    .into((ImageView) findViewById(R.id.img_profile));
        }

        // Log.i("TAG", "Place: " + place.getAddress());
        if (resultCode == AutocompleteActivity.RESULT_ERROR) {
            // TODO: Handle the error.
            Status status = Autocomplete.getStatusFromIntent(data);
            Log.i("TAG", status.getStatusMessage());
        } else if (resultCode == RESULT_CANCELED) {
            // The user canceled the operation.
        }
    }


    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);

        savedInstanceState.putString(Name, ((EditText) findViewById(R.id.name)).getText().toString());
        savedInstanceState.putString(Mail, ((EditText) findViewById(R.id.mail)).getText().toString());
        savedInstanceState.putString(Phone, ((EditText) findViewById(R.id.time_text)).getText().toString());
        savedInstanceState.putString(Photo, currentPhotoPath);
        savedInstanceState.putBoolean(CameraOpen, dialog_open);
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        ((EditText) findViewById(R.id.name)).setText(savedInstanceState.getString(Name));
        ((EditText) findViewById(R.id.mail)).setText(savedInstanceState.getString(Mail));
        ((EditText) findViewById(R.id.time_text)).setText(savedInstanceState.getString(Phone));
        currentPhotoPath = savedInstanceState.getString(Photo);
        if (currentPhotoPath != null) {
            Glide.with(getApplicationContext()).load(currentPhotoPath).into((ImageView) findViewById(R.id.img_profile));
        }

        if (savedInstanceState.getBoolean(CameraOpen))
            editPhoto();
    }

    public String getAddress(Context context, double lat, double lon) {
        String fullAdd = null;
        Log.d("Inside Loop", "Loop1");
        try {
            Geocoder geocoder = new Geocoder(context, Locale.getDefault());
            List<android.location.Address> addresses = geocoder.getFromLocation(lat, lon, 1);
            if (addresses.size() > 0) {
                Log.d("Inside", "Loop2");
                Address address1 = addresses.get(0);
                fullAdd = address1.getLocality();

            }
        } catch (IOException e) {
            Log.d("Inside", "Loop3");

            e.printStackTrace();
            Log.d("aman", e.getMessage().toString());
        }
        return fullAdd;
    }

}
