package in.example.user1.Adapters;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;

import java.util.ArrayList;

import in.example.user1.Activity.OtherServicesActivity;
import in.example.user1.R;
import in.example.user1.model.GlideApp;
import in.example.user1.model.Restaurateur;
import in.example.user1.model.ReviewItem;

import static in.example.user1.model.SharedClass.RESTAURATEUR_INFO;

public class OtherServicesAdapter extends RecyclerView.Adapter<OtherServicesAdapter.ViewHolder> implements View.OnClickListener{
    private ArrayList<Restaurateur> arrayList;
    private Context context;
    public OtherServicesAdapter(Context context, ArrayList<Restaurateur> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    public void stopListening() {
    }

    @Override
    public void onClick(View v) {

    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView restaurant_image, star_favorite, imageView4;
        private ConstraintLayout restaurant;
        private TextView restaurant_name, listview_address, listview_cuisine, listview_pren,listview_opening, profession, rating;
        private RatingBar ratingBar;
        private CardView cardView;
        private ShimmerFrameLayout shimmerFrameLayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            rating = itemView.findViewById(R.id.rating);
            restaurant_image = itemView.findViewById(R.id.restaurant_image);
            restaurant = itemView.findViewById(R.id.restaurant);
            restaurant_name = itemView.findViewById(R.id.restaurant_name);
            listview_address = itemView.findViewById(R.id.listview_address);
            listview_cuisine = itemView.findViewById(R.id.listview_cuisine);
            ratingBar = itemView.findViewById(R.id.ratingBaritem);
            star_favorite = itemView.findViewById(R.id.star_favorite);
            imageView4 = itemView.findViewById(R.id.imageView4);
            listview_pren = itemView.findViewById(R.id.listview_pren);
            listview_opening = itemView.findViewById(R.id.listview_opening);
            profession = itemView.findViewById(R.id.profession);
            cardView = itemView.findViewById(R.id.cardView);
        }
    }

    @NonNull
    @Override
    public OtherServicesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.restaurant_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull OtherServicesAdapter.ViewHolder holder, int position) {
//        if(showShimmer){
//            holder.shimmerFrameLayout.startShimmer();
//        }else {
//            holder.shimmerFrameLayout.stopShimmer();
//            holder.shimmerFrameLayout.setShimmer(null);

            Log.d("working", "aman");
            final Restaurateur restaurateur = arrayList.get(position);
            holder.star_favorite.setVisibility(View.GONE);
            holder.imageView4.setVisibility(View.GONE);
            holder.listview_pren.setVisibility(View.GONE);
            holder.listview_opening.setVisibility(View.GONE);
            holder.restaurant_name.setText(arrayList.get(position).getName());
            holder.listview_address.setText(arrayList.get(position).getAddr());
            holder.listview_cuisine.setText(arrayList.get(position).getCuisine());
            holder.profession.setVisibility(View.VISIBLE);
            holder.profession.setText(arrayList.get(position).getProfession());
            holder.cardView.setOnClickListener(v -> {
                Intent intent = new Intent(context, OtherServicesActivity.class);
                intent.putExtra("details", restaurateur);
                intent.putExtra("userUID", FirebaseAuth.getInstance().getCurrentUser().getUid());
                context.startActivity(intent);
            });
            if (arrayList.get(position).getPhotoUri() != null) {
                GlideApp.with(context)
                        .load(FirebaseStorage.getInstance().getReference().child(arrayList.get(position).getPhotoUri()))
                        .placeholder(R.drawable.ic_male)
                        .dontAnimate()
                        .centerInside()
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true)
                        .into(holder.restaurant_image);
            }

            Query getGlobalRating = FirebaseDatabase.getInstance().getReference().child(RESTAURATEUR_INFO + "/" + restaurateur.getUid()).child("review");
            getGlobalRating.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        float totRating = 0;
                        long nReviews = dataSnapshot.getChildrenCount();

                        for (DataSnapshot d : dataSnapshot.getChildren()) {
                            Log.d("aman", "working");
                            ReviewItem reviewItem = d.getValue(ReviewItem.class);
                            totRating += reviewItem.getStars();
                        }
                        Log.d("rating",Float.toString(totRating));

                        totRating = totRating / nReviews;
                        holder.ratingBar.setRating(totRating);
                        holder.rating.setText(Float.toString(totRating));
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Log.w("PAGER ADAPTER PROFILE", "Failed to read value.", databaseError.toException());
                }
            });
        }


    @Override
    public int getItemCount() {
        return arrayList.size();
    }


}
