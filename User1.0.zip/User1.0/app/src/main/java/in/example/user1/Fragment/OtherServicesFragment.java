package in.example.user1.Fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;

import java.util.ArrayList;
import java.util.HashSet;

import in.example.user1.Adapters.OtherServicesAdapter;
import in.example.user1.R;
import in.example.user1.model.Restaurateur;
import in.example.user1.notifications.APIService;
import in.example.user1.notifications.Client;
import in.example.user1.notifications.Token;

import static in.example.user1.model.SharedClass.RESTAURATEUR_INFO;

public class OtherServicesFragment extends Fragment {
    private OtherServicesAdapter adapter;
    private OnFragmentInteractionListener mListener;
    private APIService apiService;
    private ShimmerFrameLayout shimmerFrameLayout;
    private RecyclerView recyclerView;
    private ArrayList<Restaurateur> arrayList;
    private HashSet<String> cuisineType = new HashSet<>();
    private HashSet<Chip> chips = new HashSet<>();
    private ChipGroup entryChipGroup;
    private HorizontalScrollView horizontalScrollView;
    private boolean flag = true;
    boolean changed = false;

    public OtherServicesFragment() {

    }

    public static OtherServicesFragment newInstance() {
        OtherServicesFragment fragment = new OtherServicesFragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        arrayList = new ArrayList<>();

        View v = inflater.inflate(R.layout.services_other, container, false);
        shimmerFrameLayout = v.findViewById(R.id.shimmer_layout);
        entryChipGroup = v.findViewById(R.id.chip_group);
        horizontalScrollView = v.findViewById(R.id.horizontal_scroll);

        recyclerView = v.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        apiService = Client.getRetrofit("https://fcm.googleapis.com/").create(APIService.class);
        DatabaseReference myRef = FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot d : dataSnapshot.getChildren()) {
                        Log.d("profession", d.child("info").child("profession").getValue().toString());
                        String profession = d.child("info").child("profession").getValue().toString();
                        if (!(profession.equalsIgnoreCase("Store") || profession.equalsIgnoreCase("Home Chef"))) {
                            Log.d("aman", "aman");
                            Restaurateur restaurateur = new Restaurateur(d.child("info").child("mail").getValue().toString(),
                                    d.child("info").child("name").getValue().toString(),
                                    d.child("info").child("addr").getValue().toString(),
                                    d.child("info").child("cuisine").getValue().toString(),
                                    "00",
                                    d.child("info").child("phone").getValue().toString(),
                                    "null",
                                    d.child("info").child("profession").getValue().toString(),
                                    d.child("info").child("uid").getValue().toString());
                            arrayList.add(restaurateur);
                        }
                    }
                    Log.d("size", Integer.toString(arrayList.size()));

                    adapter = new OtherServicesAdapter(getActivity(), arrayList);
                    recyclerView.setAdapter(adapter);
                    shimmerFrameLayout.stopShimmer();
                    shimmerFrameLayout.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.VISIBLE);
                    horizontalScrollView.setVisibility(View.VISIBLE);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        updateToken(FirebaseInstanceId.getInstance().getToken());


        Query query = FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO);
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot d : dataSnapshot.getChildren()) {
                        if (d.child("info").child("profession").getValue().toString().equalsIgnoreCase("Store") ||
                                d.child("info").child("profession").getValue().toString().equalsIgnoreCase("Home Chef")) {
                        } else {
                            if (cuisineType.add(d.child("info").child("profession").getValue().toString())) {
                                Log.d("CHIP", cuisineType.toString());
                                Chip chip = new Chip(v.getContext());
                                chip.setCheckable(true);
                                chip.setText(d.child("info").child("profession").getValue().toString());
                                chips.add(chip);
                                entryChipGroup.addView(chip);
                                chip.setOnCheckedChangeListener((buttonView, isChecked) -> {
                                    if (isChecked && flag) {
//                                        setFilter(d.child("info").child("cuisine").getValue().toString());
                                    }
                                });
                            }
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        return v;
    }

    private void setFilter(String toString) {
        DatabaseReference myRef = FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot d : dataSnapshot.getChildren()) {
                        Log.d("profession", d.child("info").child("profession").getValue().toString());
                        String profession = d.child("info").child("profession").getValue().toString();
                        if ((!(profession.equalsIgnoreCase("Store")) || profession.equalsIgnoreCase("Home Chef")) && d.child("info").child("profession").getValue().toString().equalsIgnoreCase(toString)) {
                            Log.d("aman", "aman");
                            Restaurateur restaurateur = new Restaurateur(d.child("info").child("mail").getValue().toString(),
                                    d.child("info").child("name").getValue().toString(),
                                    d.child("info").child("addr").getValue().toString(),
                                    d.child("info").child("cuisine").getValue().toString(),
                                    "00",
                                    d.child("info").child("phone").getValue().toString(),
                                    "null",
                                    d.child("info").child("profession").getValue().toString(),
                                    d.child("info").child("uid").getValue().toString());
                            arrayList.add(restaurateur);
                        }
                    }
                    Log.d("size", Integer.toString(arrayList.size()));
                    adapter = new OtherServicesAdapter(getActivity(), arrayList);
                    recyclerView.setAdapter(adapter);
                    shimmerFrameLayout.stopShimmer();
                    shimmerFrameLayout.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.VISIBLE);
                    horizontalScrollView.setVisibility(View.VISIBLE);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        updateToken(FirebaseInstanceId.getInstance().getToken());

    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OtherServicesFragment.OnFragmentInteractionListener) {
            mListener = (OtherServicesFragment.OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    public void updateToken(String token) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Tokens");
        Token mToken = new Token(token);
        ref.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(mToken);
    }

    @Override
    public void onResume() {
        super.onResume();
        shimmerFrameLayout.startShimmer();
    }

    @Override
    public void onPause() {
        super.onPause();
    }
}