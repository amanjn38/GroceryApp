package in.example.user1.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

public final class Restaurateur implements Parcelable {
    private String mail, name, addr, cuisine, openingTime, phone, photoUri, profession, uid;
    public Restaurateur() {
        this.mail = "";
        this.name = "";
        this.addr = "";
        this.cuisine = "";
        this.phone = "";
        this.photoUri = null;
        this.profession = "";
        this.uid = "";
    }

    public Restaurateur(String mail, String name, String addr, String cuisine, String openingTime, String phone, String photoUri, String profession, String uid) {
        this.mail = mail;
        this.name = name;
        this.addr = addr;
        this.cuisine = cuisine;
        this.openingTime = openingTime;
        this.phone = phone;
        this.photoUri = photoUri;
        this.profession = profession;
        this.uid = uid;
    }

    protected Restaurateur(Parcel in) {
        mail = in.readString();
        name = in.readString();
        addr = in.readString();
        cuisine = in.readString();
        openingTime = in.readString();
        phone = in.readString();
        photoUri = in.readString();
        profession = in.readString();
        uid = in.readString();
    }

    public static final Creator<Restaurateur> CREATOR = new Creator<Restaurateur>() {
        @Override
        public Restaurateur createFromParcel(Parcel in) {
            return new Restaurateur(in);
        }

        @Override
        public Restaurateur[] newArray(int size) {
            return new Restaurateur[size];
        }
    };

    public String getMail() {
        return mail;
    }

    public String getName() {
        return name;
    }

    public String getAddr() {
        return addr;
    }

    public String getCuisine() {
        return cuisine;
    }

    public String getOpeningTime() {
        return openingTime;
    }

    public String getPhone() {
        return phone;
    }

    public String getPhotoUri() {
        return photoUri;
    }

    public String getProfession() { return profession; }

    public String getUid() { return uid; }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mail);
        dest.writeString(name);
        dest.writeString(addr);
        dest.writeString(cuisine);
        dest.writeString(openingTime);
        dest.writeString(phone);
        dest.writeString(photoUri);
        dest.writeString(profession);
        dest.writeString(uid);
    }
}