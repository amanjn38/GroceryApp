package in.example.user1.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.firebase.Timestamp;

public final class Jobs implements Parcelable {
    private Timestamp t;
    private String u, p, issue;
    private int c, otp;

    public Jobs(Timestamp t, String u, int c, int otp, String p, String issue) {
        this.t = t;  //timestamp
        this.u = u;
        this.c = c;
        this.otp = otp;
        this.p = p;
        this.issue = issue;
    }

    public Jobs() {
        this.t = null;
        this.c = 0;
        this.otp = 0;
        this.u = "";
        this.p = "";
        this.issue = "";
    }


    protected Jobs(Parcel in) {
        t = in.readParcelable(Timestamp.class.getClassLoader());
        u = in.readString();
        c = in.readInt();
        otp = in.readInt();
        p = in.readString();
        issue = in.readString();
    }

    public static final Creator<Jobs> CREATOR = new Creator<Jobs>() {
        @Override
        public Jobs createFromParcel(Parcel in) {
            return new Jobs(in);
        }

        @Override
        public Jobs[] newArray(int size) {
            return new Jobs[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(t, flags);
        dest.writeString(u);
        dest.writeInt(c);
        dest.writeInt(otp);
        dest.writeString(p);
        dest.writeString(issue);
    }

    public String getIssue() {
        return issue;
    }

    public void setIssue(String issue) {
        this.issue = issue;
    }

    public Timestamp getT() {
        return t;
    }

    public void setT(Timestamp t) {
        this.t = t;
    }

    public String getU() {
        return u;
    }

    public void setU(String u) {
        this.u = u;
    }

    public int getC() {
        return c;
    }

    public void setC(int c) {
        this.c = c;
    }

    public int getOtp() {
        return otp;
    }

    public void setOtp(int otp) {
        this.otp = otp;
    }

    public String getP() {
        return p;
    }

    public void setP(String p) {
        this.p = p;
    }
}

