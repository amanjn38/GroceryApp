package in.example.user1.Activity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;
import in.example.user1.R;
import in.example.user1.model.Restaurateur;
import in.example.user1.model.User;
import in.example.user1.notifications.APIService;
import in.example.user1.notifications.Client;
import in.example.user1.notifications.Data;
import in.example.user1.notifications.Response;
import in.example.user1.notifications.Sender;
import in.example.user1.notifications.Token;
import retrofit2.Call;
import retrofit2.Callback;

import static in.example.user1.model.SharedClass.CUSTOMER_PATH;
import static in.example.user1.model.SharedClass.ROOT_UID;
import static in.example.user1.model.SharedClass.user;

public class OtherServicesActivity extends AppCompatActivity {

    //c = 1 Job has been placed
    //c = 2  Job has been accepted by the worker
    //c = 3 Job completed, otp matches
    //c = 4 rated by the user
    //c = 5 request declined by the user
    private Restaurateur restaurateur;
    private TextView profession, name, btnConfirm;
    private CircleImageView circleImageView;
    private TextView date, time;
    private APIService apiService;
    private String userUID;
    private EditText issue;
    private int year, month, day, hour, minute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other_services);
        apiService = Client.getRetrofit("https://fcm.googleapis.com/").create(APIService.class);

        restaurateur = getIntent().getParcelableExtra("details");
        userUID = getIntent().getStringExtra("userUID");
        profession = findViewById(R.id.profession);
        name = findViewById(R.id.name);
        circleImageView = findViewById(R.id.img_profile);
        issue = findViewById(R.id.issue);
        profession.setText(restaurateur.getProfession());
        name.setText(restaurateur.getName());

        btnConfirm = findViewById(R.id.btnConfirm);
        if (restaurateur.getPhotoUri() != null)
            Glide.with(Objects.requireNonNull(this))
                    .load(restaurateur.getPhotoUri())
                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                    .placeholder(R.drawable.ic_male)
                    .dontAnimate()
                    .centerInside()
                    .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                    .into(circleImageView);
        else {
            Glide.with(Objects.requireNonNull(this))
                    .load(R.drawable.person)
                    .placeholder(R.drawable.ic_male)
                    .dontAnimate()
                    .centerInside()
                    .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                    .into(circleImageView);
        }

        year = month = day = hour = minute = -1;
        date = findViewById(R.id.date);

        time = findViewById(R.id.time);

        date.setOnClickListener(view -> {
            Calendar calendar = Calendar.getInstance();
            DatePickerDialog datePickerDialog = new DatePickerDialog(OtherServicesActivity.this,
                    (view2, year, monthOfYear, dayOfMonth) -> {
                        OtherServicesActivity.this.year = year;
                        OtherServicesActivity.this.day = dayOfMonth;
                        OtherServicesActivity.this.month = monthOfYear;
                        date.setText(generateDate(year, monthOfYear, dayOfMonth));
                    }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
            datePickerDialog.show();
        });

        time.setOnClickListener(view -> {
            Calendar calendar = Calendar.getInstance();
            TimePickerDialog mTimePicker;
            mTimePicker = new TimePickerDialog(OtherServicesActivity.this, (timePicker, selectedHour, selectedMinute) -> {
                OtherServicesActivity.this.hour = selectedHour;
                OtherServicesActivity.this.minute = selectedMinute;
                time.setText(generateTime(selectedHour, selectedMinute));
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false);//Yes 24 hour time
            mTimePicker.setTitle("Select Time");
            mTimePicker.show();
        });

        btnConfirm.setOnClickListener(v -> {
            AlertDialog dialog = new AlertDialog.Builder(OtherServicesActivity.this)
                    .setTitle("Confirmation")
                    .setMessage("Are you sure you want to confirm this job")
                    .setPositiveButton("Yes", (d, i) -> {
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference myRef = database.getReference(CUSTOMER_PATH).child(ROOT_UID);
                        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                Log.d("ROOT_UID", ROOT_UID);
                                user = dataSnapshot.child("customer_info").getValue(User.class);
                            }

                            @Override
                            public void onCancelled(DatabaseError error) {
                                Log.w("MAIN", "Failed to read value.", error.toException());
                            }
                        });
                        String issue1 = issue.getText().toString().trim();
                        Date date;
                        if (year == -1 || hour == -1) {
                            Toast.makeText(this, "Select data and time", Toast.LENGTH_SHORT).show();
                            return;
                        } else {
                            date = getDate(year, month, day, hour, minute);
                        }

                        int otp = (int) (Math.random() * 10000);
                        if (otp < 1000) otp += 1000;

                        String order_id = FirebaseDatabase.getInstance().getReference().push().getKey();
                        String notif_key = "notifications/" + restaurateur.getUid() + "/jobs/" + order_id + "/";
                        HashMap<String, Object> hashMap = new HashMap<>();
                        hashMap.put(notif_key + "t", date.getTime());
                        hashMap.put(notif_key + "u", FirebaseAuth.getInstance().getCurrentUser().getUid());
                        hashMap.put(notif_key + "c", 1);
                        hashMap.put(notif_key + "otp", otp);
                        hashMap.put(notif_key + "issue", issue1);
                        FirebaseDatabase.getInstance().getReference().updateChildren(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(OtherServicesActivity.this, "The job has been scheduled. Please keep checking your order history for status", Toast.LENGTH_LONG).show();
                                    Intent intent = new Intent(OtherServicesActivity.this, HomeActivity.class);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(OtherServicesActivity.this, "The job cannot be created", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(OtherServicesActivity.this, HomeActivity.class);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    startActivity(intent);
                                }
                            }
                        });

                        sendNotification(restaurateur.getUid(), user.getName() + "has requested a new job", "Please respond to the job accordingly");
                        String notif_key_1 = "user_notifications/" + FirebaseAuth.getInstance().getCurrentUser().getUid() + "/jobs/" + order_id + "/";

                        HashMap<String, Object> hashMap1 = new HashMap<>();
                        hashMap1.put(notif_key_1 + "t", date.getTime());
                        hashMap1.put(notif_key_1 + "u", restaurateur.getUid());
                        hashMap1.put(notif_key_1 + "c", 1);
                        hashMap1.put(notif_key_1 + "p", restaurateur.getProfession());
                        hashMap1.put(notif_key_1 + "otp", otp);
                        hashMap1.put(notif_key_1 + "issue", issue1);
                        FirebaseDatabase.getInstance().getReference().updateChildren(hashMap1).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(OtherServicesActivity.this, "The job has been scheduled. Please keep checking your order history for status", Toast.LENGTH_LONG).show();
                                } else {
                                    Toast.makeText(OtherServicesActivity.this, "The job cannot be created", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    })
                    .setNegativeButton("No", null)
                    .create();
            dialog.show();
        });
    }

    private void sendNotification(String uid, String s, String s1) {
        DatabaseReference allTokens = FirebaseDatabase.getInstance().getReference("Tokens");
        Query query = allTokens.orderByKey().equalTo(uid);
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot ds : snapshot.getChildren()) {
                    Token token = ds.getValue(Token.class);
                    Data data = new Data(FirebaseAuth.getInstance().getCurrentUser().getUid(), s, s1, uid, R.drawable.time_icon);

                    Sender sender = new Sender(data, token.getToken());
                    apiService.sendNotification(sender)
                            .enqueue(new Callback<Response>() {
                                @Override
                                public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                                    Toast.makeText(OtherServicesActivity.this, "Test Successful" + response.message(), Toast.LENGTH_LONG).show();
                                }

                                @Override
                                public void onFailure(Call<Response> call, Throwable t) {

                                }
                            });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    public static Date getDate(int year, int month, int day, int hour, int minute) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, month);
        cal.set(Calendar.DAY_OF_MONTH, day);
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    public static String generateDate(int year, int month, int day) {
        String date = day + "";
        switch (day % 10) {
            case 1:
                date += "st";
                break;
            case 2:
                date += "nd";
                break;
            case 3:
                date += "rd";
                break;
            default:
                date += "th";
        }
        switch (month) {
            case 0:
                date += " Jan";
                break;
            case 1:
                date += " Feb";
                break;
            case 2:
                date += " Mar";
                break;
            case 3:
                date += " Apr";
                break;
            case 4:
                date += " May";
                break;
            case 5:
                date += " June";
                break;
            case 6:
                date += " July";
                break;
            case 7:
                date += " Aug";
                break;
            case 8:
                date += " Sept";
                break;
            case 9:
                date += " Oct";
                break;
            case 10:
                date += " Nov";
                break;
            case 11:
                date += " Dec";
                break;
        }
        return date;
    }

    public static String generateTime(int hour, int minute) {
        String time = "";
        boolean am = true;
        if (hour >= 12) {
            am = false;
            hour -= 12;
        }
        if (hour == 0) hour = 12;

        if (hour < 10) time += "0" + hour + ":";
        else time += hour + ":";

        if (minute < 10) time += "0" + minute;
        else time += minute;

        return time + (am ? " AM" : " PM");
    }
}