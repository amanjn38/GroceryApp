package in.example.user1.UI;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.firebase.storage.FirebaseStorage;

import java.util.ArrayList;

import in.example.user1.R;
import in.example.user1.model.GlideApp;
import in.example.user1.model.Restaurateur;

class OtherServicesAdapter extends RecyclerView.Adapter<OtherServicesAdapter.ViewHolder> {
    private ArrayList<Restaurateur> arrayList;
    private Context context;

    public OtherServicesAdapter(Context context, ArrayList<Restaurateur> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView restaurant_image, star_favorite, imageView4;
        private ConstraintLayout restaurant;
        private TextView restaurant_name, listview_address, listview_cuisine, listview_pren,listview_opening, profession;
        private RatingBar ratingBar;
        private CardView cardView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            restaurant_image = itemView.findViewById(R.id.restaurant_image);
            restaurant = itemView.findViewById(R.id.restaurant);
            restaurant_name = itemView.findViewById(R.id.restaurant_name);
            listview_address = itemView.findViewById(R.id.listview_address);
            listview_cuisine = itemView.findViewById(R.id.listview_cuisine);
            ratingBar = itemView.findViewById(R.id.ratingBaritem);
            star_favorite = itemView.findViewById(R.id.star_favorite);
            imageView4 = itemView.findViewById(R.id.imageView4);
            listview_pren = itemView.findViewById(R.id.listview_pren);
            listview_opening = itemView.findViewById(R.id.listview_opening);
            profession = itemView.findViewById(R.id.profession);
            cardView = itemView.findViewById(R.id.cardView);
        }
    }

    @NonNull
    @Override
    public OtherServicesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.restaurant_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull OtherServicesAdapter.ViewHolder holder, int position) {
        Log.d("working", "aman");

        final Restaurateur restaurateur = arrayList.get(position);
        holder.star_favorite.setVisibility(View.GONE);
        holder.imageView4.setVisibility(View.GONE);
        holder.listview_pren.setVisibility(View.GONE);
        holder.listview_opening.setVisibility(View.GONE);
        holder.restaurant_name.setText(arrayList.get(position).getName());
        holder.listview_address.setText(arrayList.get(position).getAddr());
        holder.listview_cuisine.setText(arrayList.get(position).getCuisine());
        holder.profession.setVisibility(View.VISIBLE);
        holder.profession.setText(arrayList.get(position).getProfession());
        holder.cardView.setOnClickListener(v -> {
            Intent intent = new Intent(context, OtherServicesActivity.class);
            intent.putExtra("details", restaurateur);
            context.startActivity(intent);
        });
        if (arrayList.get(position).getPhotoUri() != null) {
            GlideApp.with(context)
                    .load(FirebaseStorage.getInstance().getReference().child(arrayList.get(position).getPhotoUri()))
                    .placeholder(R.drawable.ic_male)
                    .dontAnimate()
                    .centerInside()
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .skipMemoryCache(true)
                    .into(holder.restaurant_image);
        }
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }


}
