package in.example.user1.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.hsalf.smilerating.SmileRating;

import java.util.HashMap;

import in.example.user1.R;
import in.example.user1.model.ReviewItem;
import in.example.user1.model.StarItem;

import static in.example.user1.model.SharedClass.RESTAURATEUR_INFO;
import static in.example.user1.model.SharedClass.ROOT_UID;

public class RatingActivity extends AppCompatActivity {

    private String orderKey;
    private String resKey;
    private String workerUID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating);

        workerUID = getIntent().getStringExtra("workerUID");
        orderKey = getIntent().getStringExtra("orderId");
        resKey = FirebaseAuth.getInstance().getCurrentUser().getUid();

        SmileRating smileRating = (SmileRating) findViewById(R.id.dialog_rating_rating_bar);
        //Button confirm pressed
        findViewById(R.id.dialog_rating_button_positive).setOnClickListener(a -> {

            FirebaseDatabase.getInstance().getReference("notifications").child(workerUID).child("jobs").child(orderKey).child("c").setValue(4);
            FirebaseDatabase.getInstance().getReference("user_notifications").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("jobs").child(orderKey).child("c").setValue(4);

            if (smileRating.getRating() != 0) {
                DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("restaurants" + "/" + workerUID).child("review");
                DatabaseReference myRef2 = FirebaseDatabase.getInstance().getReference("user_notifications").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                        .child("jobs").child(orderKey);
                final String[] photoPath = new String[1];
                final String[] name = new String[1];
                FirebaseFirestore.getInstance().collection("Home Enterpreneurs").document(workerUID).get()
                        .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    Log.d("worker", workerUID);
                                    DocumentSnapshot d = task.getResult();
                                    Log.d("work", d.toString());
                                    name[0] = d.get("n").toString();
                                    if (d.contains("pu")) {
                                        photoPath[0] = d.get("pu").toString();
                                    }
                                    HashMap<String, Object> rated = new HashMap<>();
                                    HashMap<String, Object> review = new HashMap<>();
                                    String comment = ((EditText) findViewById(R.id.dialog_rating_feedback)).getText().toString();
                                    updateRestaurantStars(resKey, smileRating.getRating());
                                    if (!comment.isEmpty()) {
                                        rated.put("rated", true);
                                        myRef2.updateChildren(rated);
                                        review.put(myRef.push().getKey(), new ReviewItem(smileRating.getRating(), comment, ROOT_UID, photoPath[0], name[0]));
                                        myRef.updateChildren(review);
                                    } else {
                                        rated.put("rated", true);
                                        myRef2.updateChildren(rated);
                                        review.put(myRef.push().getKey(), new ReviewItem(smileRating.getRating(), null, ROOT_UID, photoPath[0], name[0]));
                                        myRef.updateChildren(review);
                                    }
                                    Toast.makeText(RatingActivity.this, "Thanks for your review!", Toast.LENGTH_LONG).show();
                                    Intent intent = new Intent(RatingActivity.this, HomeActivity.class);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(RatingActivity.this, "You forgot to rate!", Toast.LENGTH_LONG).show();
                                }
                            }
                        });
            }
        });
    }

    private void updateRestaurantStars(String resKey, int stars) {
        Query query = FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO).child(workerUID).child("stars");
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                HashMap<String, Object> star = new HashMap<>();
                DatabaseReference myRef = FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO + "/" + workerUID);
                Log.d("reskey", workerUID);
                Log.d("res", Boolean.toString(dataSnapshot.exists()));
                if (dataSnapshot.exists()) {
                    int s = ((Long) dataSnapshot.child("tot_stars").getValue()).intValue();
                    int p = ((Long) dataSnapshot.child("tot_review").getValue()).intValue();
                    star.put("stars", new StarItem(s + stars, p + 1, -s - stars));
                    myRef.updateChildren(star);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void setRated(String orderKey, boolean bool) {
        DatabaseReference myRef2 = FirebaseDatabase.getInstance().getReference("user_notifications").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .child("jobs").child(orderKey);
        HashMap<String, Object> rated = new HashMap<>();
        rated.put("rated", bool);
        myRef2.updateChildren(rated);
    }
}