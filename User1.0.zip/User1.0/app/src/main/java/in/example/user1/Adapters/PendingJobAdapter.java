package in.example.user1.Adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import in.example.user1.Activity.HomeActivity;
import in.example.user1.Activity.RatingActivity;
import in.example.user1.R;
import in.example.user1.model.Jobs;
import in.example.user1.model.ReviewItem;

import static in.example.user1.model.SharedClass.RESTAURATEUR_INFO;

public class PendingJobAdapter extends RecyclerView.Adapter<PendingJobAdapter.ViewHolder> {

    private Context context;
    private ArrayList<Jobs> arrayList;
    private ArrayList<String> stringArrayList;
    View view;

    public PendingJobAdapter(Context context, ArrayList<Jobs> arrayList, ArrayList<String> stringArrayList) {
        this.context = context;
        this.arrayList = arrayList;
        this.stringArrayList = stringArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.rejected_job_layout, parent, false));

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Log.d("jobs", arrayList.get(position).toString());
        final Jobs jobs = arrayList.get(position);
        Log.d("jobsadapter", arrayList.get(position).toString());

        String key = stringArrayList.get(position);
        Date iDate = jobs.getT().toDate();

        SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
        DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

        String dateString = dateFormatter.format(iDate);
        String timeString = timeFormat.format(iDate);

        holder.notif_day.setText(dateString);
        holder.notif_time.setText(timeString);
        holder.notif_msg.setText("The service provider has not responded to your request yet. ");
        Query getGlobalRating = FirebaseDatabase.getInstance().getReference().child(RESTAURATEUR_INFO + "/" + jobs.getU()).child("review");
        getGlobalRating.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    float totRating = 0;
                    long nReviews = dataSnapshot.getChildrenCount();

                    for (DataSnapshot d : dataSnapshot.getChildren()) {
                        Log.d("aman", "working");
                        ReviewItem reviewItem = d.getValue(ReviewItem.class);
                        totRating += reviewItem.getStars();
                    }
                    Log.d("rating", Float.toString(totRating));

                    totRating = totRating / nReviews;
                    holder.ratingBar.setRating(totRating);
                    holder.rating.setText(Float.toString(totRating));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w("PAGER ADAPTER PROFILE", "Failed to read value.", databaseError.toException());
            }
        });
        FirebaseFirestore.getInstance().collection("Home Enterpreneurs").document(jobs.getU()).get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot d = task.getResult();
                            if (d.contains("pu")) {
                                Glide.with(context)
                                        .load(d.get("pu").toString())
                                        .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                                        .placeholder(R.drawable.ic_male)
                                        .dontAnimate()
                                        .centerInside()
                                        .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                        .into(holder.notifDp);
                            } else {
                                Glide.with(context)
                                        .load(R.drawable.ic_male)
                                        .placeholder(R.drawable.ic_male)
                                        .dontAnimate()
                                        .centerInside()
                                        .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                        .into(holder.notifDp);
                            }
                        }
                    }
                });
        holder.response.setText("No response");
        holder.issue.setText(jobs.getIssue());
        holder.btnCancel.setOnClickListener(v -> {
            AlertDialog dialog = new AlertDialog.Builder(context)
                    .setMessage("Are you sure you want to cancel ?")
                    .setPositiveButton("Yes", (d, i) -> {
                        FirebaseDatabase.getInstance().getReference("notifications").child(jobs.getU()).child("jobs").child(key).removeValue();
                        FirebaseDatabase.getInstance().getReference("user_notifications").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("jobs").child(key).removeValue();
                        Intent intent = new Intent(context, HomeActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        context.startActivity(intent);
                    })
                    .setNegativeButton("No", null)
                    .create();
            dialog.show();
        });

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView notifDp;
        private TextView notif_msg, notif_day, notif_time, response;
        private ConstraintLayout bgCard;
        private RatingBar ratingBar;
        private TextView rating, issue;
        private Button btnCancel;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            view = itemView;
            issue = itemView.findViewById(R.id.issue);
            btnCancel = itemView.findViewById(R.id.btnCancel);
            rating = itemView.findViewById(R.id.rating);
            ratingBar = itemView.findViewById(R.id.ratingBaritem);
            notifDp = itemView.findViewById(R.id.notifDp);
            notif_msg = itemView.findViewById(R.id.notif_msg);
            notif_day = itemView.findViewById(R.id.notif_day);
            notif_time = itemView.findViewById(R.id.notif_time);
            bgCard = itemView.findViewById(R.id.bgCard);
            response = itemView.findViewById(R.id.response);
        }

    }

}
