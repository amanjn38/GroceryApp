package in.example.user1.UI;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import in.example.user1.R;
import in.example.user1.model.Restaurateur;

import static in.example.user1.model.SharedClass.RESTAURATEUR_INFO;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link OtherServicesFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class OtherServicesFragment extends Fragment {
    private OtherServicesAdapter adapter;
    private OnFragmentInteractionListener mListener;

        private RecyclerView recyclerView;
        private ArrayList<Restaurateur> arrayList;

    public OtherServicesFragment() {

    }

    public static OtherServicesFragment newInstance() {
        OtherServicesFragment fragment = new OtherServicesFragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        arrayList = new ArrayList<>();
        View v = inflater.inflate(R.layout.services_other, container, false);
        recyclerView = v.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        DatabaseReference myRef = FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot d : dataSnapshot.getChildren()) {
                        Log.d("profession", d.child("info").child("profession").getValue().toString());
                        String profession = d.child("info").child("profession").getValue().toString();
                        if (!(profession.equalsIgnoreCase("Grocery Store"))) {
                            Log.d("aman", "aman");
                            Restaurateur restaurateur = new Restaurateur(d.child("info").child("mail").getValue().toString(),
                                    d.child("info").child("name").getValue().toString(),
                                    d.child("info").child("addr").getValue().toString(),
                                    d.child("info").child("cuisine").getValue().toString(),
                                    "00",
                                    d.child("info").child("phone").getValue().toString(),
                                    "null",
                                    d.child("info").child("profession").getValue().toString(),
                                    d.child("info").child("uid").getValue().toString());
                            arrayList.add(restaurateur);
                        }
                    }
                    Log.d("size", Integer.toString(arrayList.size()));

                    adapter = new OtherServicesAdapter(getActivity(), arrayList);
                    recyclerView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        return v;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OtherServicesFragment.OnFragmentInteractionListener) {
            mListener = (OtherServicesFragment.OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

}