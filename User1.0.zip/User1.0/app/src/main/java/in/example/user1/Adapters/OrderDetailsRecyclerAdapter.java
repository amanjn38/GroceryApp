package in.example.user1.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.DecimalFormat;
import java.util.ArrayList;
import static in.example.user1.model.SharedClass.*;
import in.example.user1.R;

public class OrderDetailsRecyclerAdapter extends RecyclerView.Adapter<OrderDetailsRecyclerAdapter.MyViewHolder> implements Filterable {
    private ArrayList<String> keys;
    private ArrayList<String> nums;
    private String key;
    LayoutInflater mInflater;

    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView dish_name;
        TextView dish_quant;
        TextView dish_price;
        View view_item;

        public MyViewHolder(View itemView){
            super(itemView);
            this.view_item = itemView;
            dish_name = itemView.findViewById(R.id.orderdetail_dishname);
            dish_price = itemView.findViewById(R.id.orderdetail_price);
            dish_quant = itemView.findViewById(R.id.orderdetail_quantity);
        }
        public View getView_item (){
            return this.view_item;
        }

        public void setData(String key_dish, String num){
            Query query = FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO).child(key).child("dishes").child(key_dish);
            query.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    dish_name.setText((String)dataSnapshot.child("name").getValue());
                    dish_price.setText((new DecimalFormat("#.##")).format(dataSnapshot.child("price").getValue()).toString()+" ₹");
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
            dish_quant.setText(num);
        }
    }


    public OrderDetailsRecyclerAdapter(Context context, ArrayList<String> keys, ArrayList<String> nums, String key) {
        mInflater = LayoutInflater.from(context);
        this.keys = keys;
        this.nums = nums;
        this.key = key;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view =  mInflater.inflate(R.layout.detailorder_dishitem, parent, false);
        return new MyViewHolder(view);
    }


    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.setData(keys.get(position), nums.get(position));

    }


    @Override
    public int getItemCount() {
        return this.keys.size();
    }

    @Override
    public Filter getFilter() {
        return null;
    }
}
