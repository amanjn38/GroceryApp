package in.example.restaurant.Startup;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Spinner;
import in.example.restaurant.R;

public class SelectionActivity extends AppCompatActivity {

    private Spinner profession;
    private Button btnContinue;
    private boolean update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);

        profession = findViewById(R.id.profession);
        btnContinue = findViewById(R.id.btnContinue);


        update = getIntent().getBooleanExtra("update", false);

        btnContinue.setOnClickListener(v -> {
            new AlertDialog.Builder(SelectionActivity.this)
                    .setTitle("Are you sure you want to continue")
                    .setMessage("Press Yes to continue and No to change profession")
                    .setNegativeButton("No", null)
                    .setPositiveButton("Yes", (d,i) ->{
                        Intent intent = new Intent(SelectionActivity.this, SignUp.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.putExtra("p", profession.getSelectedItem().toString());
                        intent.putExtra("update", update);
                        startActivity(intent);
                    })
                    .create()
                    .show();
        });
    }
}
