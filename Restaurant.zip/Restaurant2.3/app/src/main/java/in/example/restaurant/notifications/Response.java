package in.example.restaurant.notifications;

public class Response {

    private String success;
}
