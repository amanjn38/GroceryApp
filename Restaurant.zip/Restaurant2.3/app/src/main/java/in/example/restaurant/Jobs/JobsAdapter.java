package in.example.restaurant.Jobs;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import in.example.restaurant.notifications.*;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

import in.example.restaurant.R;
import in.example.restaurant.Startup.MainActivity;
import in.example.restaurant.model.Jobs;
import in.example.restaurant.model.Restaurateur;
import in.example.restaurant.notifications.APIService;
import in.example.restaurant.notifications.Sender;
import retrofit2.Call;
import retrofit2.Callback;

import static in.example.restaurant.model.SharedClass.RESTAURATEUR_INFO;
import static in.example.restaurant.model.SharedClass.ROOT_UID;

class JobsAdapter extends RecyclerView.Adapter<JobsAdapter.ViewHolder> {

    private Context context;
    private ArrayList<Jobs> arrayList;
    private ArrayList<String> stringArrayList;
    private APIService apiService;


    public JobsAdapter(Context context, ArrayList<Jobs> arrayList, ArrayList<String> stringArrayList) {
        this.context = context;
        this.arrayList = arrayList;
        this.stringArrayList = stringArrayList;
    }

    @NonNull
    @Override
    public JobsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        switch (viewType) {
            case 1:
                return new JobRequest(LayoutInflater.from(parent.getContext()).inflate(R.layout.job_request_row, parent, false));
            case 2:
                return new ActiveJob(LayoutInflater.from(parent.getContext()).inflate(R.layout.active_jobs_layout, parent, false));
            case 3:
                return new CompletedJob(LayoutInflater.from(parent.getContext()).inflate(R.layout.completed_jobs_layout, parent, false));
            case 5:
                return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.rejected_jobs_layout, parent, false));
        }
        return new JobRequest(LayoutInflater.from(parent.getContext()).inflate(R.layout.job_request_row, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull JobsAdapter.ViewHolder holder, int position) {
        final Jobs jobs = arrayList.get(position);
        Log.d("jobsadapter", arrayList.get(position).toString());

        String key = stringArrayList.get(position);
        Date iDate = jobs.getT().toDate();

        SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
        DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

        String dateString = dateFormatter.format(iDate);
        String timeString = timeFormat.format(iDate);

        holder.notif_day.setText(dateString);
        holder.notif_time.setText(timeString);

        apiService = Client.getRetrofit("https://fcm.googleapis.com/").create(APIService.class);

        switch (holder.getItemViewType()) {
            case 1:
                ((JobRequest) holder).issue.setText(jobs.getIssue());
                FirebaseFirestore.getInstance().collection("customers").document(jobs.getU()).get()
                        .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    DocumentSnapshot d = task.getResult();
                                    holder.notif_msg.setText("You have a new Job request from " + d.get("n").toString() + ".Please accept the request if you are available for it.");
                                    ((JobRequest) holder).address.setText(d.get("add").toString());
                                    if (d.contains("pu")) {
                                        Glide.with(context)
                                                .load(d.get("pu").toString())
                                                .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                                                .placeholder(R.drawable.ic_male)
                                                .dontAnimate()
                                                .centerInside()
                                                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                                .into(holder.notifDp);
                                    } else {
                                        Glide.with(context)
                                                .load(R.drawable.person)
                                                .placeholder(R.drawable.ic_male)
                                                .dontAnimate()
                                                .centerInside()
                                                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                                .into(holder.notifDp);
                                    }
                                }
                            }
                        });

                ((JobRequest) holder).btnAccept.setOnClickListener(v -> {
                    AlertDialog dialog = new AlertDialog.Builder(context)
                            .setTitle("Are you sure you want to accept this job ?")
                            .setPositiveButton("Yes", (d, i) -> {
                                FirebaseDatabase.getInstance().getReference("notifications").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("jobs").child(key).child("c").setValue(2);
                                FirebaseDatabase.getInstance().getReference("user_notifications").child(jobs.getU()).child("jobs").child(key).child("c").setValue(2);
                                sendNotification(arrayList.get(position).getU(), "Has accepted your job", "Please respond to the job accordingly");

                            })
                            .setNegativeButton("No", null)
                            .create();
                    dialog.show();
                });

                ((JobRequest) holder).btnReject.setOnClickListener(v -> {
                    AlertDialog dialog = new AlertDialog.Builder(context)
                            .setTitle("Are you sure you want to reject this job ?")
                            .setPositiveButton("Yes", (d, i) -> {
                                FirebaseDatabase.getInstance().getReference("notifications").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("jobs").child(key).child("c").setValue(5);
                                FirebaseDatabase.getInstance().getReference("user_notifications").child(jobs.getU()).child("jobs").child(key).child("c").setValue(5);
                            })
                            .setNegativeButton("No", null)
                            .create();
                    dialog.show();
                });
                break;
            case 2:
                final String[] phone = new String[1];
                final double[] lt = new double[1];
                final double[] lo = new double[1];
                holder.notif_msg.setText("You have a job scheduled at the following date and time.");
                ((ActiveJob) holder).issue.setText(jobs.getIssue());

                Query query1 = FirebaseDatabase.getInstance().getReference().child(RESTAURATEUR_INFO + "/" + ROOT_UID).child("info_pos");
                Query getRestaurantInfo = FirebaseDatabase.getInstance().getReference().child(RESTAURATEUR_INFO + "/" + ROOT_UID).child("info");
                getRestaurantInfo.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            Restaurateur restaurateur = dataSnapshot.getValue(Restaurateur.class);
                            phone[0] = restaurateur.getPhone();
                            String photoUri = restaurateur.getPhotoUri();
                            if (photoUri != null) {
                                Glide.with(Objects.requireNonNull(context))
                                        .load(photoUri)
                                        .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                                        .into(holder.notifDp);
                            } else {
                                Glide.with(Objects.requireNonNull(context))
                                        .load(R.drawable.ic_male)
                                        .into(holder.notifDp);
                            }
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        Log.w("PAGER ADAPTER PROFILE", "Failed to read value.", error.toException());
                    }
                });

                query1.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            lt[0] = (Double.parseDouble(dataSnapshot.child("latitude").getValue().toString()));
                            lo[0] = (Double.parseDouble(dataSnapshot.child("longitude").getValue().toString()));

                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        Log.w("DAILY OFFER", "Failed to read value.", error.toException());
                    }
                });

                ((ActiveJob) holder).map.setOnClickListener(v -> {
                    String strUri = "http://maps.google.com/maps?q=loc:" + lt[0] + "," + lo[0] + " (" + "Label which you want" + ")";
                    Intent intent = new Intent(android.content.Intent.ACTION_VIEW, Uri.parse(strUri));
                    intent.setClassName("com.google.android.apps.maps", "com.google.android.maps.MapsActivity");
                    context.startActivity(intent);
                });

                ((ActiveJob)holder).call.setOnClickListener(view -> {
                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone[0]));
                    if(ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){
                        return;
                    }
                    context.startActivity(intent);
                });
                break;
            case 3:
                holder.notif_msg.setText("You have completed the job.");
                Query getRestaurantInfo1 = FirebaseDatabase.getInstance().getReference().child(RESTAURATEUR_INFO + "/" + ROOT_UID).child("info");
                getRestaurantInfo1.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            Restaurateur restaurateur = dataSnapshot.getValue(Restaurateur.class);
                            String photoUri = restaurateur.getPhotoUri();
                            if (photoUri != null) {
                                Glide.with(Objects.requireNonNull(context))
                                        .load(photoUri)
                                        .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                                        .dontAnimate()
                                        .centerInside()
                                        .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                        .into(holder.notifDp);
                            } else {
                                Glide.with(Objects.requireNonNull(context))
                                        .load(R.drawable.ic_male)
                                        .dontAnimate()
                                        .centerInside()
                                        .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                        .into(holder.notifDp);
                            }
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        Log.w("PAGER ADAPTER PROFILE", "Failed to read value.", error.toException());
                    }
                });
                ((CompletedJob)holder).issue.setText(jobs.getIssue());
                break;

            case 5:
                holder.notif_msg.setText("You have rejected the following job");
                break;
        }


    }

    @Override
    public int getItemViewType(int position) {
        if (arrayList.get(position).getC() == 1) {
            return 1;
        } else if (arrayList.get(position).getC() == 2) {
            return 2;
        } else if (arrayList.get(position).getC() == 3 || arrayList.get(position).getC() == 4) {
            return 3;
        } else {
            return 5;
        }
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    private void sendNotification(String uid, String s, String s1) {
        DatabaseReference allTokens = FirebaseDatabase.getInstance().getReference("Tokens");
        Query query = allTokens.orderByKey().equalTo(uid);
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot ds : snapshot.getChildren()){
                    Token token = ds.getValue(Token.class);
                    Data data = new Data(FirebaseAuth.getInstance().getCurrentUser().getUid(), s,s1,uid,R.drawable.time_icon);

                    Sender sender = new Sender(data, token.getToken());
                    apiService.sendNotification(sender)
                            .enqueue(new Callback<Response>() {
                                @Override
                                public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                                    Toast.makeText(context, "Test Successful"+response.message(), Toast.LENGTH_LONG).show();
                                }

                                @Override
                                public void onFailure(Call<Response> call, Throwable t) {

                                }
                            });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView notifDp;
        private TextView notif_msg, notif_day, notif_time;
        private ConstraintLayout bgCard;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            notifDp = itemView.findViewById(R.id.notifDp);
            notif_msg = itemView.findViewById(R.id.notif_msg);
            notif_day = itemView.findViewById(R.id.notif_day);
            notif_time = itemView.findViewById(R.id.notif_time);
            bgCard = itemView.findViewById(R.id.bgCard);
        }
    }

    class JobRequest extends ViewHolder {
        Button btnAccept, btnReject;
        TextView address, issue;

        public JobRequest(View v) {
            super(v);
            issue = v.findViewById(R.id.issue);
            btnAccept = v.findViewById(R.id.btnAccept);
            btnReject = v.findViewById(R.id.btnReject);
            address = v.findViewById(R.id.address);
        }
    }

    class ActiveJob extends ViewHolder {
        ImageView map, call;
        TextView address, phone, issue;

        public ActiveJob(View v) {
            super(v);
            issue = v.findViewById(R.id.issue);
            map = v.findViewById(R.id.map);
            call = v.findViewById(R.id.call);
            address = v.findViewById(R.id.address);
            phone = v.findViewById(R.id.phone);
        }
    }

    class CompletedJob extends ViewHolder {
        TextView address, issue;

        public CompletedJob(View v) {
            super(v);
            issue = v.findViewById(R.id.issue);
            address = v.findViewById(R.id.address);
        }
    }
}
