package in.example.restaurant.Startup;

public class ScreenItem {

        int ScreenImg;
        private String headline, subHeadline;

        public ScreenItem(int screenImg, String headline, String subHeadline) {
            ScreenImg = screenImg;
            this.headline = headline;
            this.subHeadline = subHeadline;
        }

        public int getScreenImg() {
            return ScreenImg;
        }

        public void setScreenImg(int screenImg) {
            ScreenImg = screenImg;
        }

        public String getHeadline() {
            return headline;
        }

        public void setHeadline(String headline) {
            this.headline = headline;
        }

        public String getSubHeadline() {
            return subHeadline;
        }

        public void setSubHeadline(String subHeadline) {
            this.subHeadline = subHeadline;
        }
    }