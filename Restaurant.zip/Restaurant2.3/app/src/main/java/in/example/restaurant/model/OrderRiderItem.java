package in.example.restaurant.model;

import java.util.HashMap;

public class OrderRiderItem {
    private String keyRestaurant;
    private String keyCustomer;
    private String addrCustomer;
    private String addrRestaurant;
    private String totPrice;
    private Long time;
    public HashMap<String, Integer> dishes; //key = dish name, value = quantity

    public OrderRiderItem() {

    }

    public OrderRiderItem(String keyRestaurant, String keyCustomer, String addrCustomer, String addrRestaurant, Long time, String totPrice, HashMap<String, Integer> dishes) {
        this.keyRestaurant = keyRestaurant;
        this.keyCustomer = keyCustomer;
        this.addrCustomer = addrCustomer;
        this.addrRestaurant = addrRestaurant;
        this.time = time;
        this.totPrice = totPrice;
        this.dishes = dishes;

    }

    public String getKeyRestaurant() {
        return keyRestaurant;
    }

    public void setKeyRestaurant(String keyRestaurant) {
        this.keyRestaurant = keyRestaurant;
    }

    public String getKeyCustomer() {
        return keyCustomer;
    }

    public void setKeyCustomer(String keyCustomer) {
        this.keyCustomer = keyCustomer;
    }

    public String getAddrCustomer() {
        return addrCustomer;
    }

    public void setAddrCustomer(String addrCustomer) {
        this.addrCustomer = addrCustomer;
    }

    public String getAddrRestaurant() {
        return addrRestaurant;
    }

    public void setAddrRestaurant(String addrRestaurant) {
        this.addrRestaurant = addrRestaurant;
    }

    public String getTotPrice() {
        return totPrice;
    }

    public void setTotPrice(String totPrice) {
        this.totPrice = totPrice;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public HashMap<String, Integer> getDishes() {
        return dishes;
    }

    public void setDishes(HashMap<String, Integer> dishes) {
        this.dishes = dishes;
    }
}
