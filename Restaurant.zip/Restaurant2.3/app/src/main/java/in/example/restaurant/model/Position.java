package in.example.restaurant.model;

public class Position {
    public Double latitude, longitude;

    public Position() {

    }

    public Position(Double latitude, Double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }
}