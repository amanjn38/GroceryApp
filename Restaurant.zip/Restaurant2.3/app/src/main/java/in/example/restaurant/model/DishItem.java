package in.example.restaurant.model;

public class DishItem {
    private String name;
    private String desc;
    private float price;
    private int quantity;
    private String photo;
    private int frequency;
    private int offer;

    public DishItem() {
        this.name = "";
        this.desc = "";
        this.price = 0;
        this.quantity = 0;
        this.photo = null;
        this.frequency = 0;
        this.offer = 0;
    }

    public DishItem(String name, String desc, float price, int quantity, String photo, int frequency, int offer) {
        this.name = name;
        this.desc = desc;
        this.price = price;
        this.quantity = quantity;
        this.photo = photo;
        this.frequency = frequency;
        this.offer = offer;
    }

    public String getName() {
        return name;
    }

    public String getDesc() {
        return desc;
    }

    public float getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getPhoto() {
        return photo;
    }

    public int getFrequency() {
        return frequency;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public void setFrequency(int frequency) {
        this.frequency = frequency;
    }

    public int getOffer() {
        return offer;
    }

    public void setOffer(int offer) {
        this.offer = offer;
    }
}
