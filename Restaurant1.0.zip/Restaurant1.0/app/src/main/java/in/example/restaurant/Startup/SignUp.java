package in.example.restaurant.Startup;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.icu.text.SimpleDateFormat;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import in.example.restaurant.R;
import in.example.restaurant.model.Restaurateur;
import in.example.restaurant.model.StarItem;

import static in.example.restaurant.model.SharedClass.PERMISSION_GALLERY_REQUEST;
import static in.example.restaurant.model.SharedClass.RESTAURATEUR_INFO;
import static in.example.restaurant.model.SharedClass.ROOT_UID;
import static in.example.restaurant.model.SharedClass.SIGNUP;

public class SignUp extends AppCompatActivity {
    private String mail, psw, name, addr, descr, phone, errMsg = "", currentPhotoPath = null;
    private String openingTime, closingTime;
    LocationManager locationManager;
    private double latitude, longitude;
    private static final int REQUEST_LOCATION = 1;
    private ProgressDialog progressDialog;
    private LatLng source;
    public static int AUTOCOMPLETE_SOURCE = 180;
    private int ohour, ominute, chour, cminute;
    private TextView openingTimeButton, closingTimeButton;
    private FirebaseAuth firebaseAuth;
    private EditText address;
    private TextView profession;
    private String prof;
    private boolean update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        progressDialog = new ProgressDialog(this);
        String apikey = "AIzaSyAzScFoOmgLSQsVPK7QT4btN9wIhjoP4qM";

        List<Place.Field> fields = Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG);
        try {
            Places.initialize(SignUp.this, apikey);
        } catch (Exception e) {
        }
        //  Places.initialize(getApplicationContext(), "AIzaSyAzScFoOmgLSQsVPK7QT4btN9wIhjoP4qM");
        // Create a new Places client instance.
        PlacesClient placesClient = Places.createClient(this);
        // Set the fields to specify which types of place data to return.

        // Places.initialize(SignUp.this, getString(R.string.google_maps_key));
        // List<Place.Field> fields = Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG);
        //   FirebaseAuth auth = FirebaseAuth.getInstance();
        address = findViewById(R.id.address);
        profession = findViewById(R.id.profession);
        prof = getIntent().getStringExtra("p");
        profession.setText(prof);
        address.setOnClickListener(v ->
                startActivityForResult(new Intent(SignUp.this, MapPickerActivity.class), AUTOCOMPLETE_SOURCE));


        firebaseAuth = FirebaseAuth.getInstance();
        update = getIntent().getBooleanExtra("update", false);

        findViewById(R.id.img_profile).setOnClickListener(e -> editPhoto());

        openingTimeButton = findViewById(R.id.openingTime);
        openingTimeButton.setOnClickListener(view -> {
            Calendar calendar = Calendar.getInstance();
            TimePickerDialog mTimePicker;
            mTimePicker = new TimePickerDialog(SignUp.this, (timePicker, selectedHour, selectedMinute) -> {
                ohour = selectedHour;
                ominute = selectedMinute;
                openingTimeButton.setText(generateTime(selectedHour, selectedMinute));
                openingTime = generateTime(selectedHour, selectedMinute);
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false);//Yes 24 hour time
            mTimePicker.setTitle("Select Time");
            mTimePicker.show();
        });
//        openingTime = hourString + ":" + minString;

        //openingTimeButton.setOnClickListener(h -> setOpeningTimeDialog());
        if (update) {
            findViewById(R.id.holderEmail).setVisibility(View.GONE);
            findViewById(R.id.holderPass).setVisibility(View.GONE);
        }
        closingTimeButton = findViewById(R.id.openingTime1);

        closingTimeButton.setOnClickListener(view -> {
            Calendar calendar = Calendar.getInstance();
            TimePickerDialog mTimePicker;
            mTimePicker = new TimePickerDialog(SignUp.this, (timePicker, selectedHour, selectedMinute) -> {
                chour = selectedHour;
                cminute = selectedMinute;
                closingTimeButton.setText(generateTime(selectedHour, selectedMinute));
                closingTime = generateTime(selectedHour, selectedMinute);
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false);//Yes 24 hour time
            mTimePicker.setTitle("Select Time");
            mTimePicker.show();
        });
        //closingTimeButton.setOnClickListener(h -> setClosingTimeDialog());

        if (prof.equalsIgnoreCase("Grocery Store")) {
            findViewById(R.id.pickupHolder).setVisibility(View.VISIBLE);
        }
        findViewById(R.id.button).setOnClickListener(e -> {
            if (checkFields()) {
                progressDialog = new ProgressDialog(SignUp.this);
                progressDialog.setTitle("Creating profile.\nOperation may take few minutes...");
                progressDialog.setCancelable(false);
                progressDialog.show();
                if (!update) {
                    firebaseAuth.createUserWithEmailAndPassword(mail, psw).addOnCompleteListener(this, task -> {
                        if (task.isSuccessful()) {
                            Log.d("Inside ", "Authentication");
                            ROOT_UID = firebaseAuth.getUid();
                            storeDatabase();
                        } else {
                            //Log.w("SIGN IN", "Error: createUserWithEmail:failure", task.getException());
                            Toast.makeText(SignUp.this, "Registration failed. Try again", Toast.LENGTH_LONG).show();
                            progressDialog.dismiss();
                        }
                    });
                } else if (update) {
                    storeDatabase();
                } else {
                    Toast.makeText(SignUp.this, errMsg, Toast.LENGTH_LONG).show();
                }
            }

        });


    }

    public static String generateTime(int hour, int minute) {
        String time = "";
        boolean am = true;
        if (hour >= 12) {
            am = false;
            hour -= 12;
        }
        if (hour == 0) hour = 12;

        if (hour < 10) time += "0" + hour + ":";
        else time += hour + ":";

        if (minute < 10) time += "0" + minute;
        else time += minute;
        if (am) {
            time += " am";
        } else {
            time += " pm";
        }
        return time;
    }

    private void OnGPS() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Enable GPS").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(
                SignUp.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                SignUp.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        } else {
            Location locationGPS = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (locationGPS != null) {
                double lat = locationGPS.getLatitude();
                double longi = locationGPS.getLongitude();
                latitude = lat;
                longitude = longi;
            }
        }
    }

    public boolean checkFields() {
        if (update) {
            mail = FirebaseAuth.getInstance().getCurrentUser().getUid();
        } else {
            mail = ((EditText) findViewById(R.id.mail)).getText().toString();
        }
        psw = ((EditText) findViewById(R.id.psw)).getText().toString();
        name = ((EditText) findViewById(R.id.name)).getText().toString();
        addr = ((EditText) findViewById(R.id.address)).getText().toString();
        descr = ((EditText) findViewById(R.id.description)).getText().toString();
        phone = ((EditText) findViewById(R.id.time_text)).getText().toString();

        if (!update) {
            if (mail.trim().length() == 0 || !android.util.Patterns.EMAIL_ADDRESS.matcher(mail).matches()) {
                errMsg = "Invalid Mail";
                return false;
            }

            if (psw.trim().length() < 6) {
                errMsg = "Password should be at least 6 characters";
                return false;
            }
        }
        if (name.trim().length() == 0) {
            errMsg = "Fill name";
            return false;
        }

        if (addr.trim().length() == 0) {
            errMsg = "Fill address";
            return false;
        }

        if (phone.trim().length() != 10) {
            errMsg = "Invalid phone number";
            return false;
        }

        if (prof.equalsIgnoreCase("Grocery Store")) {
            if (openingTime.trim().length() == 0) {
                errMsg = "Fill opening time";
                return false;
            }

            if (closingTime.trim().length() == 0) {
                errMsg = "Fill closing time";
                return false;
            }
        }


        return true;
    }

    private void editPhoto() {
        AlertDialog alertDialog = new AlertDialog.Builder(SignUp.this, R.style.AlertDialogStyle).create();
        LayoutInflater factory = LayoutInflater.from(SignUp.this);
        final View view = factory.inflate(R.layout.custom_dialog, null);

        alertDialog.setOnCancelListener(dialog -> {
            alertDialog.dismiss();
        });

        view.findViewById(R.id.camera).setOnClickListener(c -> {
            cameraIntent();
            alertDialog.dismiss();
        });
        view.findViewById(R.id.gallery).setOnClickListener(g -> {
            galleryIntent();
            alertDialog.dismiss();
        });

        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Camera", (dialog, which) -> {
            cameraIntent();
            dialog.dismiss();
        });
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Gallery", (dialog, which) -> {
            galleryIntent();
            dialog.dismiss();
        });
        alertDialog.show();
    }

    private void cameraIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            File photoFile = createImageFile();

            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "in.example.restaurant.fileprovider",
                        photoFile);

                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, 2);
            }
        }
    }

    private void galleryIntent() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    PERMISSION_GALLERY_REQUEST);
        } else {
            Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
            photoPickerIntent.setType("image/*");
            startActivityForResult(photoPickerIntent, 1);
        }
    }

    private File createImageFile() {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "IMG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = new File(storageDir + File.separator +
                imageFileName + /* prefix */
                ".jpg"
        );

        // Save a file: path for use with ACTION_VIEW intents
        currentPhotoPath = image.getAbsolutePath();

        return image;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == PERMISSION_GALLERY_REQUEST) {// If request is cancelled, the result arrays are empty.
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("Permission Run Time: ", "Obtained");

                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                photoPickerIntent.setType("image/*");
                startActivityForResult(photoPickerIntent, 1);
            } else {
                Log.d("Permission Run Time: ", "Denied");

                Toast.makeText(getApplicationContext(), "Access to media files denied", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if ((requestCode == 1) && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();

            String[] filePathColumn = {MediaStore.Images.Media.DATA};

            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();

            currentPhotoPath = picturePath;
        }

        if ((requestCode == 1 || requestCode == 2) && resultCode == RESULT_OK) {
            Glide.with(getApplicationContext()).load(currentPhotoPath).into((ImageView) findViewById(R.id.img_profile));
        }
        if ((requestCode == AUTOCOMPLETE_SOURCE)) {
            if (resultCode == RESULT_OK) {
                address.setText(data.getStringExtra("name"));
                source = data.getParcelableExtra("location");
                latitude = source.latitude;
                longitude = source.longitude;
            }
        }
        if (currentPhotoPath != null) {
            Glide.with(Objects.requireNonNull(this))
                    .load(currentPhotoPath)
                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                    .into((ImageView) findViewById(R.id.img_profile));
        } else {
            Glide.with(Objects.requireNonNull(this))
                    .load(R.drawable.ic_male)
                    .into((ImageView) findViewById(R.id.img_profile));
        }
        if (resultCode == AutocompleteActivity.RESULT_ERROR) {
            // TODO: Handle the error.
            Status status = Autocomplete.getStatusFromIntent(data);
            Log.i("TAG", status.getStatusMessage());
        }  // The user canceled the operation.
    }

    public void storeDatabase() {

        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        String strmail;
        if (update) {
            strmail = FirebaseAuth.getInstance().getCurrentUser().getEmail();
        } else {
            strmail = ((EditText) findViewById(R.id.mail)).getText().toString();
        }
        String strpsw = ((EditText) findViewById(R.id.psw)).getText().toString();
        String strname = ((EditText) findViewById(R.id.name)).getText().toString();
        String straddr = ((EditText) findViewById(R.id.address)).getText().toString();
        String strdescr = ((EditText) findViewById(R.id.description)).getText().toString();
        String strphone = ((EditText) findViewById(R.id.time_text)).getText().toString();

        HashMap<String, Object> infor = new HashMap<>();
        infor.put("e", strmail);
        infor.put("p", strpsw);
        infor.put("n", strname);
        infor.put("add", straddr);
        infor.put("d", strdescr);
        infor.put("ph", strphone);
        infor.put("prof", prof);
        infor.put("lt", latitude);
        infor.put("lo", longitude);
        if (currentPhotoPath != null) {
            infor.put("pu", currentPhotoPath);
        }
        if (prof.equalsIgnoreCase("Grocery Store")) {
            infor.put("oT", openingTime);
            infor.put("cT", closingTime);
        }
        infor.put("uid", uid);
        FirebaseFirestore.getInstance().collection("Home Enterpreneurs").document(uid).set(infor).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(SignUp.this, "Your data has been stored successfully", Toast.LENGTH_LONG).show();
                }
            }
        });
        DatabaseReference myRef;
        Log.d("Inside", "Store");
        if (update) {
            myRef = FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO + "/" + FirebaseAuth.getInstance().getCurrentUser().getUid());
        } else {
            myRef = FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO + "/" + ROOT_UID);
        }
        Map<String, Object> restMap = new HashMap<>();
        Map<String, Object> posInfoMap = new HashMap<>();

        if (currentPhotoPath != null) {
            Uri photoUri = Uri.fromFile(new File(currentPhotoPath));
            StorageReference storageReference = FirebaseStorage.getInstance().getReference();
            StorageReference ref = storageReference.child("images/" + UUID.randomUUID().toString());

            ref.putFile(photoUri).continueWithTask(task -> {
                if (!task.isSuccessful()) {
                    progressDialog.dismiss();
                    throw Objects.requireNonNull(task.getException());
                }
                return ref.getDownloadUrl();
            }).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Uri downUri = task.getResult();

                    if (update) {
                        String email1 = FirebaseAuth.getInstance().getCurrentUser().getEmail();
                        restMap.put("info", new Restaurateur(email1, name, addr, descr,
                                openingTime + " - " + closingTime, phone, downUri.toString(), prof, uid));
                        myRef.updateChildren(restMap);
                    } else {
                        restMap.put("info", new Restaurateur(mail, name, addr, descr,
                                openingTime + " - " + closingTime, phone, downUri.toString(), prof, uid));
                        myRef.updateChildren(restMap);
                    }


                    posInfoMap.put("info_pos", new LatLng(latitude, longitude));
                    myRef.updateChildren(posInfoMap);

                    restMap.clear();
                    restMap.put("stars", new StarItem(0, 0, 0));
                    myRef.updateChildren(restMap);

                    progressDialog.dismiss();

                    if (prof.equalsIgnoreCase("Grocery Store")) {
                        Intent intent = new Intent(SignUp.this, MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    } else {
                        Intent intent = new Intent(SignUp.this, FragmentManagerJobs.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }

                    Intent i = new Intent();
                    setResult(SIGNUP, i);

                } else {
                    //Log.w("LOGIN", "signInWithCredential:failure", task.getException());
                    progressDialog.dismiss();
                    Snackbar.make(findViewById(R.id.email), "Authentication Failed. Try again.", Snackbar.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(e -> {
                progressDialog.dismiss();
                Snackbar.make(findViewById(R.id.email), "Authentication Failed. Try again.", Snackbar.LENGTH_SHORT).show();
            });
        } else {
            Log.d("Inside", "Maps");
            if (update) {
                String email1 = FirebaseAuth.getInstance().getCurrentUser().getEmail();
                restMap.put("info", new Restaurateur(email1, name, addr, descr,
                        openingTime + " - " + closingTime, phone, null, prof, uid));
                myRef.updateChildren(restMap);
            } else {
                restMap.put("info", new Restaurateur(mail, name, addr, descr,
                        openingTime + " - " + closingTime, phone, null, prof, uid));
                myRef.updateChildren(restMap);

            }

            posInfoMap.put("info_pos", new LatLng(latitude, longitude));
            myRef.updateChildren(posInfoMap);

            restMap.clear();
            restMap.put("stars", new StarItem(0, 0, 0));
            myRef.updateChildren(restMap);

            progressDialog.dismiss();
            if (prof.equalsIgnoreCase("Grocery Store")) {
                Intent intent = new Intent(SignUp.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            } else {
                Intent intent = new Intent(SignUp.this, FragmentManagerJobs.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }

            Intent i = new Intent();
            setResult(SIGNUP, i);
        }
    }

    public String getAddress(Context context, double lat, double lon) {
        String fullAdd = null;
        Log.d("Inside Loop", "Loop1");
        try {
            Geocoder geocoder = new Geocoder(context, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(lat, lon, 1);
            if (addresses.size() > 0) {
                Log.d("Inside", "Loop2");
                Address address1 = addresses.get(0);
                fullAdd = address1.getAddressLine(0);

            }
        } catch (IOException e) {
            Log.d("Inside", "Loop3");

            e.printStackTrace();
            Log.d("aman", e.getMessage().toString());
        }
        return fullAdd;
    }
}



