package in.example.restaurant.Startup;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Arrays;

import in.example.restaurant.R;

import static in.example.restaurant.model.SharedClass.RESTAURATEUR_INFO;
import static in.example.restaurant.model.SharedClass.ROOT_UID;
import static in.example.restaurant.model.SharedClass.SIGNUP;


public class MainActivity extends AppCompatActivity {

    private String email, password, errMsg = "";
    private CallbackManager mFacebookManager;
    private ProgressDialog progressDialog;
    private FirebaseAuth firebaseAuth;
    private final static int RC_SIGN_IN = 1;
    private GoogleApiClient mGoogleSignInClient;
    private ImageView ivFacebook, ivGoogle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivFacebook = findViewById(R.id.ivFacebook);
        ivGoogle = findViewById(R.id.ivGoogle);
        firebaseAuth = FirebaseAuth.getInstance();
        mFacebookManager = CallbackManager.Factory.create();
        FirebaseAuth auth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);

        boolean update = getIntent().getBooleanExtra("update", false);

        if (auth.getCurrentUser() != null) {
            FirebaseFirestore.getInstance().collection("Home Enterpreneurs").document(auth.getCurrentUser().getUid()).get()
                    .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                            if (task.isSuccessful()) {
                                DocumentSnapshot documentSnapshot = task.getResult();
                                if (documentSnapshot.get("prof").toString().equalsIgnoreCase("Grocery Store")) {
                                    Intent fragment = new Intent(MainActivity.this, FragmentManager.class);
                                    startActivity(fragment);
                                    finish();
                                } else {
                                    Intent fragment = new Intent(MainActivity.this, FragmentManagerJobs.class);
                                    startActivity(fragment);
                                    finish();
                                }
                            }
                        }
                    });
        }
        if (auth.getCurrentUser() == null) {
            progressDialog.setTitle("Authenticating...");

            findViewById(R.id.sign_up).setOnClickListener(e -> {
                Intent login = new Intent(this, in.example.restaurant.Startup.SelectionActivity.class);
                startActivityForResult(login, SIGNUP);
            });

            findViewById(R.id.login).setOnClickListener(h -> {
                if (checkFields()) {
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                    auth.signInWithEmailAndPassword(email, password)
                            .addOnCompleteListener(this, task -> {
                                if (task.isSuccessful()) {
                                    ROOT_UID = auth.getUid();
                                    progressDialog.dismiss();
                                    FirebaseFirestore.getInstance().collection("Home Enterpreneurs").document(ROOT_UID).get()
                                            .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                                @Override
                                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                                    if (task.isSuccessful()) {
                                                        DocumentSnapshot documentSnapshot = task.getResult();
                                                        if (documentSnapshot.get("prof").toString().equalsIgnoreCase("Grocery Store")) {
                                                            Intent fragment = new Intent(MainActivity.this, FragmentManager.class);
                                                            startActivity(fragment);
                                                            finish();
                                                        } else {
                                                            Intent fragment = new Intent(MainActivity.this, FragmentManagerJobs.class);
                                                            startActivity(fragment);
                                                            finish();
                                                        }
                                                    }
                                                }
                                            });

                                } else {
                                    //Log.w("LOGIN", "signInWithCredential:failure", task.getException());
                                    progressDialog.dismiss();
                                    Snackbar.make(findViewById(R.id.email), "Authentication Failed. Try again.", Snackbar.LENGTH_SHORT).show();
                                    Intent fragment = new Intent(this, in.example.restaurant.Startup.SelectionActivity.class);
                                    startActivity(fragment);
                                }
                            })
                            .addOnFailureListener(e -> {
                                progressDialog.dismiss();
                                Snackbar.make(findViewById(R.id.email), "Authentication Failed. Try again.", Snackbar.LENGTH_SHORT).show();
                            });
                } else {
                    Snackbar.make(findViewById(R.id.email), errMsg, Snackbar.LENGTH_SHORT).show();
                }
            });
        } else {
            ROOT_UID = auth.getUid();
            Intent fragment = new Intent(this, FragmentManager.class);
            startActivity(fragment);
            finish();
        }

        ivGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signIn();
            }
        });

        // Configure Google Sign In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        mGoogleSignInClient = new GoogleApiClient.Builder(this).enableAutoManage(this, new GoogleApiClient.OnConnectionFailedListener() {
            @Override
            public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
                Toast.makeText(MainActivity.this, "Connection to google sign in failed", Toast.LENGTH_SHORT).show();

            }
        }).addApi(Auth.GOOGLE_SIGN_IN_API, gso).build();

        FacebookSdk.sdkInitialize(getApplicationContext());

        ivFacebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ivFacebook.setEnabled(false);

                LoginManager.getInstance().logInWithReadPermissions(MainActivity.this, Arrays.asList("email", "public_profile", "user_friends"));
                LoginManager.getInstance().registerCallback(mFacebookManager, new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        //Toast.makeText(MainActivity.this,"Login successful",Toast.LENGTH_LONG).show();
                        handleFacebookAccessToken(loginResult.getAccessToken());
                    }

                    @Override
                    public void onCancel() {
                        Toast.makeText(MainActivity.this, "On Cancel", Toast.LENGTH_LONG).show();
                        ivFacebook.setEnabled(true);
                    }

                    @Override
                    public void onError(FacebookException error) {
                        Toast.makeText(MainActivity.this, "On Error" + error.toString(), Toast.LENGTH_LONG).show();
                        ivFacebook.setEnabled(true);
                    }
                });
            }
        });
    }

    private void signIn() {
        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleSignInClient);
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN) {
            progressDialog.setTitle("Google Sign In");
            progressDialog.setMessage("Logging in using your google account");
            progressDialog.setCanceledOnTouchOutside(true);
            progressDialog.show();
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            if (result.isSuccess()) {
                GoogleSignInAccount account = result.getSignInAccount();
                firebaseAuthWithGoogle(account);
                Toast.makeText(MainActivity.this, "Please wait, while we are getting your auth results", Toast.LENGTH_LONG).show();
                progressDialog.dismiss();
            } else {
                progressDialog.dismiss();
                Toast.makeText(MainActivity.this, "Can't get Auth results", Toast.LENGTH_SHORT).show();
            }
        } else {
            mFacebookManager.onActivityResult(requestCode, resultCode, data);
        }
        if (data != null && resultCode == SIGNUP) {
            Intent fragment = new Intent(this, MainActivity.class);
            startActivity(fragment);
            finish();
        }


    }

    private void firebaseAuthWithGoogle(GoogleSignInAccount account) {
        //Log.d(TAG, "firebaseAuthWithGoogle:" + account.getId());

        AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(MainActivity.this, "Signed In successfully", Toast.LENGTH_SHORT).show();
                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                            final boolean[] flag = {false};
                            FirebaseDatabase.getInstance().getReference().child(RESTAURATEUR_INFO)
                                    .child(user.getUid())
                                    .child("customer_info").addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.hasChild("addr")) {
                                        Log.d("Inside", "True");
                                        progressDialog.dismiss();
                                        if (dataSnapshot.child("profession").getValue().toString().equalsIgnoreCase("Grocery Store")) {
                                            Intent intent = new Intent(MainActivity.this, FragmentManager.class);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                            startActivity(intent);
                                        } else {
                                            Intent intent = new Intent(MainActivity.this, FragmentManagerJobs.class);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                            startActivity(intent);
                                        }
                                    } else {
                                        progressDialog.dismiss();
                                        Intent intent = new Intent(MainActivity.this, SelectionActivity.class);
                                        intent.putExtra("update", true);
                                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                }
                            });
                            // updateUI();

                        }
                    }
                });
    }

    private void handleFacebookAccessToken(AccessToken token) {
        //Toast.makeText(MainActivity.this,"Handle facebook handle token" + token,Toast.LENGTH_LONG).show();
        AuthCredential credential = FacebookAuthProvider.getCredential(token.getToken());
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Toast.makeText(MainActivity.this, "Signed In successfully", Toast.LENGTH_SHORT).show();
                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                            final boolean[] flag = {false};
                            FirebaseDatabase.getInstance().getReference().child(RESTAURATEUR_INFO)
                                    .child(user.getUid())
                                    .child("info").addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.hasChild("addr")) {
                                        Log.d("Inside", "True");
                                        progressDialog.dismiss();
                                        if (dataSnapshot.child("profession").getValue().toString().equalsIgnoreCase("Grocery Store")) {
                                            Intent intent = new Intent(MainActivity.this, FragmentManager.class);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                            startActivity(intent);
                                        } else {
                                            Intent intent = new Intent(MainActivity.this, FragmentManagerJobs.class);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                            startActivity(intent);
                                        }
                                    } else {
                                        progressDialog.dismiss();
                                        Intent intent = new Intent(MainActivity.this, SelectionActivity.class);
                                        intent.putExtra("update", true);
                                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                }
                            });
                            // updateUI();

                            // updateUI();
                        } else {
                            // If sign in fails, display a message to the user.
                            Toast.makeText(MainActivity.this, "Login failed", Toast.LENGTH_LONG).show();
                            Toast.makeText(MainActivity.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                            Log.d("Error", task.getException().toString());
                            ivFacebook.setEnabled(true);
                            //updateUI();
                        }

                    }
                });
    }

    public boolean checkFields() {
        email = ((EditText) findViewById(R.id.email)).getText().toString();
        password = ((EditText) findViewById(R.id.password)).getText().toString();

        if (email.trim().length() == 0 || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            errMsg = "Invalid Mail";
            return false;
        }

        if (password.trim().length() == 0) {
            errMsg = "Fill password";
            return false;
        }

        return true;
    }
}