package in.example.restaurant.ProfileActivities;

import android.Manifest;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.icu.text.SimpleDateFormat;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import in.example.restaurant.R;
import in.example.restaurant.Startup.MapPickerActivity;
import in.example.restaurant.model.Restaurateur;

import static in.example.restaurant.model.SharedClass.Address;
import static in.example.restaurant.model.SharedClass.Description;
import static in.example.restaurant.model.SharedClass.Latitude;
import static in.example.restaurant.model.SharedClass.Longitude;
import static in.example.restaurant.model.SharedClass.Mail;
import static in.example.restaurant.model.SharedClass.Name;
import static in.example.restaurant.model.SharedClass.PERMISSION_GALLERY_REQUEST;
import static in.example.restaurant.model.SharedClass.Phone;
import static in.example.restaurant.model.SharedClass.Photo;
import static in.example.restaurant.model.SharedClass.Profession;
import static in.example.restaurant.model.SharedClass.RESTAURATEUR_INFO;
import static in.example.restaurant.model.SharedClass.ROOT_UID;
import static in.example.restaurant.model.SharedClass.Time;

public class EditProfile extends AppCompatActivity {
    private String name, addr, desc, mail, phone, currentPhotoPath, time, prof, lat, lon;
    private String error_msg = " ";
    private int ohour, ominute, chour, cminute;
    private String openingTime, closingTime;
    private EditText address;
    private TextView openingTimeButton, closingTimeButton;
    private boolean photoChanged = false;
    private double latitude;
    private LatLng source;
    private double longitude;
    private String update;
    public static int AUTOCOMPLETE_SOURCE = 180;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        getData();

        // Initialize Places.
        Places.initialize(getApplicationContext(), "AIzaSyAzScFoOmgLSQsVPK7QT4btN9wIhjoP4qM");
        // Create a new Places client instance.
        PlacesClient placesClient = Places.createClient(this);
        // Set the fields to specify which types of place data to return.
        List<Place.Field> fields = Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG, Place.Field.ADDRESS);

        address = findViewById(R.id.button_address2);
        address.setOnClickListener(l -> {
            startActivityForResult(new Intent(EditProfile.this, MapPickerActivity.class), AUTOCOMPLETE_SOURCE);
        });

        update = getIntent().getStringExtra(Profession);
        if (update.equalsIgnoreCase("Grocery Store")) {
            findViewById(R.id.pickupHolder).setVisibility(View.VISIBLE);
        }
        openingTimeButton = findViewById(R.id.openingTime);
        openingTimeButton.setOnClickListener(view -> {
            Calendar calendar = Calendar.getInstance();
            TimePickerDialog mTimePicker;
            mTimePicker = new TimePickerDialog(EditProfile.this, (timePicker, selectedHour, selectedMinute) -> {
                ohour = selectedHour;
                ominute = selectedMinute;
                openingTimeButton.setText(generateTime(selectedHour, selectedMinute));
                openingTime = generateTime(selectedHour, selectedMinute);
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false);//Yes 24 hour time
            mTimePicker.setTitle("Select Time");
            mTimePicker.show();
        });

        closingTimeButton = findViewById(R.id.openingTime1);

        closingTimeButton.setOnClickListener(view -> {
            Calendar calendar = Calendar.getInstance();
            TimePickerDialog mTimePicker;
            mTimePicker = new TimePickerDialog(EditProfile.this, (timePicker, selectedHour, selectedMinute) -> {
                chour = selectedHour;
                cminute = selectedMinute;
                closingTimeButton.setText(generateTime(selectedHour, selectedMinute));
                closingTime = generateTime(selectedHour, selectedMinute);
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false);//Yes 24 hour time
            mTimePicker.setTitle("Select Time");
            mTimePicker.show();
        });
        findViewById(R.id.button).setOnClickListener(e -> {
            if (checkFields()) {
                storeDatabase();
            } else {
                Toast.makeText(getApplicationContext(), error_msg, Toast.LENGTH_LONG).show();
            }
        });

        findViewById(R.id.img_profile).setOnClickListener(e -> editPhoto());
    }

    private boolean checkFields() {
        name = ((EditText) findViewById(R.id.name)).getText().toString();
        addr = ((EditText) findViewById(R.id.button_address2)).getText().toString();
        desc = ((EditText) findViewById(R.id.description)).getText().toString();
        mail = ((EditText) findViewById(R.id.mail)).getText().toString();
        phone = ((EditText) findViewById(R.id.time_text)).getText().toString();
        prof = ((EditText) findViewById(R.id.profession)).getText().toString();

        if (update.equalsIgnoreCase("Grocery Store")) {
            findViewById(R.id.pickupHolder).setVisibility(View.VISIBLE);

            time = openingTime + " - " + closingTime;

            if (openingTime.trim().length() == 0) {
                error_msg = "Fill opening time";
                return false;
            }

            if (closingTime.trim().length() == 0) {
                error_msg = "Fill closing time";
                return false;
            }
        }

        if (name.trim().length() == 0) {
            error_msg = "Fill name";
            return false;
        }

        if (addr.trim().length() == 0) {
            error_msg = "Fill address";
            return false;
        }

        if (mail.trim().length() == 0 || !android.util.Patterns.EMAIL_ADDRESS.matcher(mail).matches()) {
            error_msg = "Invalid mail";
            return false;
        }

        if (phone.trim().length() != 10) {
            error_msg = "Invalid phone number";
            return false;
        }

        return true;
    }

    private void getData() {
        Intent i = getIntent();

        name = i.getStringExtra(Name);
        addr = i.getStringExtra(Address);
        desc = i.getStringExtra(Description);
        mail = i.getStringExtra(Mail);
        phone = i.getStringExtra(Phone);
        prof = i.getStringExtra(Profession);
        lat = i.getStringExtra(Latitude);
        lon = i.getStringExtra(Longitude);

        currentPhotoPath = i.getStringExtra(Photo);
        if (prof.equalsIgnoreCase("Grocery Store")) {
            findViewById(R.id.pickupHolder).setVisibility(View.VISIBLE);

            time = i.getStringExtra(Time);
            openingTime = time.split("-")[0].trim();
            closingTime = time.split("-")[1].trim();

            ((TextView) findViewById(R.id.openingTime)).setText(openingTime);
            ((TextView) findViewById(R.id.openingTime1)).setText(closingTime);
        } else {
            time = null;
        }

        ((EditText) findViewById(R.id.name)).setText(name);
        ((EditText) findViewById(R.id.button_address2)).setText(addr);
        ((EditText) findViewById(R.id.description)).setText(desc);
        ((EditText) findViewById(R.id.mail)).setText(mail);
        ((EditText) findViewById(R.id.time_text)).setText(phone);
        ((EditText) findViewById(R.id.profession)).setText(prof);

        if (currentPhotoPath != null) {
            Glide.with(Objects.requireNonNull(this))
                    .load(currentPhotoPath)
                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                    .into((ImageView) findViewById(R.id.img_profile));
        } else {
            Glide.with(Objects.requireNonNull(this))
                    .load(R.drawable.ic_male)
                    .into((ImageView) findViewById(R.id.img_profile));
        }
    }

    private void editPhoto() {
        AlertDialog alertDialog = new AlertDialog.Builder(EditProfile.this, R.style.AlertDialogStyle).create();
        LayoutInflater factory = LayoutInflater.from(EditProfile.this);
        final View view = factory.inflate(R.layout.custom_dialog, null);

        alertDialog.setOnCancelListener(dialog -> {
            alertDialog.dismiss();
        });

        view.findViewById(R.id.camera).setOnClickListener(c -> {
            cameraIntent();
            alertDialog.dismiss();
        });
        view.findViewById(R.id.gallery).setOnClickListener(g -> {
            galleryIntent();
            alertDialog.dismiss();
        });

        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Camera", (dialog, which) -> {
            cameraIntent();
            dialog.dismiss();
        });
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Gallery", (dialog, which) -> {
            galleryIntent();
            dialog.dismiss();
        });
        alertDialog.show();
    }

    private void cameraIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            File photoFile = createImageFile();

            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this, "in.example.restaurant.fileprovider",
                        photoFile);
                photoChanged = true;

                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, 2);
            }
        }
    }

    private void galleryIntent() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    PERMISSION_GALLERY_REQUEST);
        } else {
            Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
            photoPickerIntent.setType("image/*");
            startActivityForResult(photoPickerIntent, 1);
        }
    }

    private File createImageFile() {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "IMG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = new File(storageDir + File.separator +
                imageFileName + /* prefix */
                ".jpg"
        );

        // Save a file: path for use with ACTION_VIEW intents
        currentPhotoPath = image.getAbsolutePath();

        return image;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == PERMISSION_GALLERY_REQUEST) {// If request is cancelled, the result arrays are empty.
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("Permission Run Time: ", "Obtained");

                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                photoPickerIntent.setType("image/*");
                startActivityForResult(photoPickerIntent, 1);
            } else {
                Log.d("Permission Run Time: ", "Denied");

                Toast.makeText(getApplicationContext(), "Access to media files denied", Toast.LENGTH_LONG).show();
            }
        }
    }

    public static String generateTime(int hour, int minute) {
        String time = "";
        boolean am = true;
        if (hour >= 12) {
            am = false;
            hour -= 12;
        }
        if (hour == 0) hour = 12;

        if (hour < 10) time += "0" + hour + ":";
        else time += hour + ":";

        if (minute < 10) time += "0" + minute;
        else time += minute;

        if (am) {
            time += " am";
        } else {
            time += " pm";
        }
        return time;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if ((requestCode == 1) && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            photoChanged = true;

            String[] filePathColumn = {MediaStore.Images.Media.DATA};

            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();

            currentPhotoPath = picturePath;
        }

        if ((requestCode == 1 || requestCode == 2) && resultCode == RESULT_OK) {
            Glide.with(getApplicationContext()).load(currentPhotoPath).into((ImageView) findViewById(R.id.img_profile));
        }
        if ((requestCode == AUTOCOMPLETE_SOURCE)) {
            if (resultCode == RESULT_OK) {
                address.setText(data.getStringExtra("name"));
                source = data.getParcelableExtra("location");
                latitude = source.latitude;
                longitude = source.longitude;
            }
        }
        if (currentPhotoPath != null) {
            Glide.with(Objects.requireNonNull(this))
                    .load(currentPhotoPath)
                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                    .into((ImageView) findViewById(R.id.img_profile));
        } else {
            Glide.with(Objects.requireNonNull(this))
                    .load(R.drawable.restaurant_home)
                    .into((ImageView) findViewById(R.id.img_profile));
        }
        if (resultCode == AutocompleteActivity.RESULT_ERROR) {
            // TODO: Handle the error.
            Status status = Autocomplete.getStatusFromIntent(data);
            Log.i("TAG", status.getStatusMessage());
        } else if (resultCode == RESULT_CANCELED) {
            // The user canceled the operation.
        }
    }

    private void storeDatabase() {
//
//        latitude = Double.parseDouble(lat);
//        longitude = Double.parseDouble(lon);

        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        String strmail = ((EditText) findViewById(R.id.mail)).getText().toString();
        String strname = ((EditText) findViewById(R.id.name)).getText().toString();

        String straddr = ((EditText) findViewById(R.id.button_address2)).getText().toString();
        String strdescr = ((EditText) findViewById(R.id.description)).getText().toString();
        String strphone = ((EditText) findViewById(R.id.time_text)).getText().toString();

        HashMap<String, Object> infor = new HashMap<>();
        infor.put("e", strmail);
        infor.put("n", strname);
        infor.put("add", straddr);
        infor.put("d", strdescr);
        infor.put("ph", strphone);
        infor.put("prof", prof);
        if (latitude != 0) {
            infor.put("lt", latitude);
            infor.put("lo", longitude);
        } else {
            infor.put("lt", lat);
            infor.put("lo", lon);
        }
        if (update.equalsIgnoreCase("Grocery Store")) {
            infor.put("oT", openingTime);
            infor.put("cT", closingTime);
        }
        FirebaseFirestore.getInstance().collection("Home Enterpreneurs").document(FirebaseAuth.getInstance().getCurrentUser().getUid()).update(infor).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(EditProfile.this, "Your data has been stored successfully", Toast.LENGTH_LONG).show();
                }
            }
        });
        DatabaseReference myRef = FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO + "/" + ROOT_UID);
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        Map<String, Object> profileMap = new HashMap<>();
        Map<String, Object> posInfoMap = new HashMap<>();

        if (photoChanged && currentPhotoPath != null) {
            Uri photoUri = Uri.fromFile(new File(currentPhotoPath));
            StorageReference ref = storageReference.child("images/" + UUID.randomUUID().toString());

            ref.putFile(photoUri).continueWithTask(task -> {
                if (!task.isSuccessful()) {
                    throw Objects.requireNonNull(task.getException());
                }
                return ref.getDownloadUrl();
            }).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Uri downUri = task.getResult();

                    profileMap.put("info", new Restaurateur(mail, name, addr, desc, time, phone, downUri.toString(), prof, uid));
                    myRef.updateChildren(profileMap);

                    Log.d("lati", String.valueOf(latitude));
                    Log.d("longi", String.valueOf(longitude));
                    Log.d("lat", lat);
                    Log.d("lon", lon);



                    finish();
                }
            });
        } else {
            if (currentPhotoPath != null)
                profileMap.put("info", new Restaurateur(mail, name, addr, desc, time, phone, currentPhotoPath, prof,uid));
            else
                profileMap.put("info", new Restaurateur(mail, name, addr, desc, time, phone, null, prof,uid));

            myRef.updateChildren(profileMap);
            if (latitude != 0 && longitude!=0) {
                Log.d("working", "AMan");
                posInfoMap.put("info_pos", new LatLng(latitude, longitude));
                myRef.updateChildren(posInfoMap);
            } else {
                posInfoMap.put("info_pos", new LatLng(Double.parseDouble(lat), Double.parseDouble(lon)));
                myRef.updateChildren(posInfoMap);
            }

            finish();
        }
    }
}