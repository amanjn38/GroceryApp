package in.example.restaurant.Jobs;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import in.example.restaurant.R;
import in.example.restaurant.model.Jobs;

class JobsAdapter extends RecyclerView.Adapter<JobsAdapter.ViewHolder> {

    private Context context;
    private ArrayList<Jobs> arrayList;
    private ArrayList<String> stringArrayList;


    public JobsAdapter(Context context, ArrayList<Jobs> arrayList, ArrayList<String> stringArrayList) {
        this.context = context;
        this.arrayList = arrayList;
        this.stringArrayList = stringArrayList;
    }

    @NonNull
    @Override
    public JobsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        switch (viewType) {
            case 1:
                return new JobRequest(LayoutInflater.from(parent.getContext()).inflate(R.layout.job_request_row, parent, false));
            case 2:
                return new ActiveJob(LayoutInflater.from(parent.getContext()).inflate(R.layout.active_jobs_layout, parent, false));
            case 3:
                return new CompletedJob(LayoutInflater.from(parent.getContext()).inflate(R.layout.completed_jobs_layout, parent, false));
            case 5:
                return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.rejected_jobs_layout, parent, false));
        }
        return new JobRequest(LayoutInflater.from(parent.getContext()).inflate(R.layout.job_request_row, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull JobsAdapter.ViewHolder holder, int position) {
        final Jobs jobs = arrayList.get(position);
        Log.d("jobsadapter", arrayList.get(position).toString());

        String key = stringArrayList.get(position);
        Date iDate = jobs.getT().toDate();

        SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
        DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

        String dateString = dateFormatter.format(iDate);
        String timeString = timeFormat.format(iDate);

        holder.notif_day.setText(dateString);
        holder.notif_time.setText(timeString);


        switch (holder.getItemViewType()) {
            case 1:
                FirebaseFirestore.getInstance().collection("customers").document(jobs.getU()).get()
                        .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    DocumentSnapshot d = task.getResult();
                                    holder.notif_msg.setText("You have a new Job request from " +d.get("n").toString() + ".Please accept the request if you are available for it.");
                                    ((JobRequest)holder).address.setText(d.get("add").toString());
                                    if (d.contains("pu")) {
                                        Glide.with(context)
                                                .load(d.get("pu").toString())
                                                .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                                                .placeholder(R.drawable.ic_male)
                                                .dontAnimate()
                                                .centerInside()
                                                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                                .into(holder.notifDp);
                                    } else {
                                        Glide.with(context)
                                                .load(R.drawable.person)
                                                .placeholder(R.drawable.ic_male)
                                                .dontAnimate()
                                                .centerInside()
                                                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                                .into(holder.notifDp);
                                    }
                                }
                            }
                        });

                ((JobRequest)holder).btnAccept.setOnClickListener(v -> {
                    AlertDialog dialog = new AlertDialog.Builder(context)
                            .setTitle("Are you sure you want to accept this job ?")
                            .setPositiveButton("Yes", (d, i) -> {
                                FirebaseDatabase.getInstance().getReference("notifications").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("jobs").child(key).child("c").setValue(2);
                                FirebaseDatabase.getInstance().getReference("user_notifications").child(jobs.getU()).child("jobs").child(key).child("c").setValue(2);
                            })
                            .setNegativeButton("No", null)
                            .create();
                    dialog.show();
                });

                ((JobRequest)holder).btnReject.setOnClickListener(v -> {
                    AlertDialog dialog = new AlertDialog.Builder(context)
                            .setTitle("Are you sure you want to reject this job ?")
                            .setPositiveButton("Yes", (d, i) -> {
                                FirebaseDatabase.getInstance().getReference("notifications").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("jobs").child(key).child("c").setValue(5);
                                FirebaseDatabase.getInstance().getReference("user_notifications").child(jobs.getU()).child("jobs").child(key).child("c").setValue(5);
                            })
                            .setNegativeButton("No", null)
                            .create();
                    dialog.show();
                });
                break;
            case 2:
                final String[] phone = new String[1];
                final double[] lt = new double[1];
                final double[] lo = new double[1];
                holder.notif_msg.setText("You have a job scheduled at the following date and time");
                FirebaseFirestore.getInstance().collection("customers").document(jobs.getU()).get()
                        .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    DocumentSnapshot d = task.getResult();
                                    ((ActiveJob)holder).address.setText(d.get("add").toString());
                                    phone[0] = d.get("ph").toString();
                                    lo[0] = d.getDouble("lo");
                                    lt[0] = d.getDouble("lt");
                                    if (d.contains("pu")) {
                                        Glide.with(context)
                                                .load(d.get("pu").toString())
                                                .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                                                .placeholder(R.drawable.ic_male)
                                                .dontAnimate()
                                                .centerInside()
                                                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                                .into(holder.notifDp);
                                    } else {
                                        Glide.with(context)
                                                .load(R.drawable.person)
                                                .placeholder(R.drawable.ic_male)
                                                .dontAnimate()
                                                .centerInside()
                                                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                                .into(holder.notifDp);
                                    }
                                }
                            }
                        });



                ((ActiveJob)holder).map.setOnClickListener(v -> {
                    String strUri = "http://maps.google.com/maps?q=loc:" + lt[0] + "," + lo[0] + " (" + "Label which you want" + ")";
                    Intent intent = new Intent(android.content.Intent.ACTION_VIEW, Uri.parse(strUri));
                    intent.setClassName("com.google.android.apps.maps", "com.google.android.maps.MapsActivity");
                    context.startActivity(intent);
                });

                ((ActiveJob)holder).call.setOnClickListener(v -> {
                    Intent callIntent = new Intent(Intent.ACTION_CALL);
                    Log.d("phone", phone[0].toString());
                    callIntent.setData(Uri.parse("tel:" + "+91" + phone[0]));//change the number
                    if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                        // TODO: Consider calling
                        //    ActivityCompat#requestPermissions
                        // here to request the missing permissions, and then overriding
                        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                        //                                          int[] grantResults)
                        // to handle the case where the user grants the permission. See the documentation
                        // for ActivityCompat#requestPermissions for more details.
                        return;
                    }
                    context.startActivity(callIntent);
                });
                break;
            case 3:
                holder.notif_msg.setText("You have completed the job.");

                break;

            case 5:
                holder.notif_msg.setText("You have rejected the following job");
                break;
        }


    }

    @Override
    public int getItemViewType(int position) {
        if (arrayList.get(position).getC() == 1) {
            return 1;
        } else if (arrayList.get(position).getC() == 2) {
            return 2;
        } else if (arrayList.get(position).getC() == 3 || arrayList.get(position).getC() == 4) {
            return 3;
        } else {
            return 5;
        }
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView notifDp;
        private TextView notif_msg, notif_day, notif_time;
        private ConstraintLayout bgCard;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            notifDp = itemView.findViewById(R.id.notifDp);
            notif_msg = itemView.findViewById(R.id.notif_msg);
            notif_day = itemView.findViewById(R.id.notif_day);
            notif_time = itemView.findViewById(R.id.notif_time);
            bgCard = itemView.findViewById(R.id.bgCard);
        }
    }

    class JobRequest extends ViewHolder {
        Button btnAccept, btnReject;
        TextView address;

        public JobRequest(View v) {
            super(v);
            btnAccept = v.findViewById(R.id.btnAccept);
            btnReject = v.findViewById(R.id.btnReject);
            address = v.findViewById(R.id.address);
        }
    }

    class ActiveJob extends ViewHolder {
        ImageView map, call;
        TextView address, phone;

        public ActiveJob(View v) {
            super(v);
            map = v.findViewById(R.id.map);
            call = v.findViewById(R.id.call);
            address = v.findViewById(R.id.address);
            phone = v.findViewById(R.id.phone);
        }
    }

    class CompletedJob extends ViewHolder {
        RatingBar ratingBar;
        TextView address, rating;

        public CompletedJob(View v) {
            super(v);
            rating = v.findViewById(R.id.rating);
            ratingBar = v.findViewById(R.id.ratingBaritem);
            address = v.findViewById(R.id.address);
        }
    }
}
