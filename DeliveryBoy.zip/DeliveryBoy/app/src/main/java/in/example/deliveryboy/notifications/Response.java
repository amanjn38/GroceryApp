package in.example.deliveryboy.notifications;

public class Response {

    private String success;
}
