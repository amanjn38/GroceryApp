package in.example.deliveryboy;

import android.app.AlertDialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import in.example.deliveryboy.model.OrderItem;
import in.example.deliveryboy.model.OrderRiderItem;
import in.example.deliveryboy.model.User;

import static in.example.deliveryboy.model.SharedClass.CUSTOMER_PATH;
import static in.example.deliveryboy.model.SharedClass.RESERVATION_PATH;
import static in.example.deliveryboy.model.SharedClass.RESTAURATEUR_INFO;
import static in.example.deliveryboy.model.SharedClass.RIDERS_ORDER;
import static in.example.deliveryboy.model.SharedClass.RIDERS_PATH;
import static in.example.deliveryboy.model.SharedClass.ROOT_UID;
import static in.example.deliveryboy.model.SharedClass.STATUS_UNKNOWN;
import static in.example.deliveryboy.model.SharedClass.user;
import static in.example.deliveryboy.model.Utilities.getDateFromTimestamp;

public class ReservationAdapter extends RecyclerView.Adapter<ReservationAdapter.ViewHolder> {

    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<OrderRiderItem> orderRiderItems;
    private Context context;
    private RecyclerView recyclerView_ordered;
    private ArrayList<String> stringArrayList;
    private RecyclerAdapterOrdered mAdapter_ordered;

    public ReservationAdapter() {

    }

    public ReservationAdapter(Context context, ArrayList<OrderRiderItem> orderRiderItems, ArrayList<String> stringArrayList) {
        this.context = context;
        this.orderRiderItems = orderRiderItems;
        this.stringArrayList = stringArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.reservation_listview, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final OrderRiderItem orderRiderItem = orderRiderItems.get(position);
        holder.delivery_address.setText(orderRiderItem.getAddrCustomer());
        holder.textView_time.setText(getDateFromTimestamp(orderRiderItem.getTime()));
        holder.listview_address.setText(orderRiderItem.getAddrRestaurant());
        holder.listview_toPay.setText(orderRiderItem.getTotPrice());

        holder.open_reservation.setOnClickListener(k ->
                viewOrder(stringArrayList.get(position)));

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference(CUSTOMER_PATH).child(orderRiderItem.getKeyCustomer());

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Log.d("ROOT_UID", ROOT_UID);
                user = dataSnapshot.child("customer_info").getValue(User.class);

                if (user.getPhotoPath() != null)
                    Glide.with(Objects.requireNonNull(context))
                            .load(user.getPhotoPath())
                            .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                            .into((ImageView) holder.profile_image);
                else
                    Glide.with(Objects.requireNonNull(context))
                            .load(R.drawable.ic_male)
                            .into((ImageView) holder.profile_image);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("MAIN", "Failed to read value.", error.toException());
            }
        });

        holder.confirm_reservation.setOnClickListener(v -> {
                    new AlertDialog.Builder(context)
                            .setTitle("Are you sure you want to accept this order.?")
                            .setNegativeButton("No", null)
                            .setPositiveButton("Yes", (d, i) -> {
                                Map<String, Object> orderMap = new HashMap<>();
                                orderMap.put(Objects.requireNonNull(stringArrayList.get(position)), orderRiderItem);
                                DatabaseReference addOrderToRider = database.getReference(RIDERS_PATH + "/" + FirebaseAuth.getInstance().getCurrentUser().getUid() + RIDERS_ORDER);
                                addOrderToRider.updateChildren(orderMap);

//                  setting to 'false' the availability of that rider
                                DatabaseReference setFalse = database.getReference(RIDERS_PATH + "/" + FirebaseAuth.getInstance().getCurrentUser().getUid() + "/available");
                                setFalse.setValue(false);

                                FirebaseDatabase database1 = FirebaseDatabase.getInstance();
                                Query query = database1.getReference().child(RIDERS_PATH + "/" + FirebaseAuth.getInstance().getCurrentUser().getUid()
                                        + "/" + RESERVATION_PATH).child(stringArrayList.get(position));

                                query.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        if (snapshot.exists()) {
                                            snapshot.getRef().removeValue();
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });
                            })
                            .create()
                            .show();
                }
        );

        holder.delete_reservation.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Are you sure you want to reject this order.?")
                    .setNegativeButton("No", null)
                    .setPositiveButton("Yes", (d, i) -> {
                        FirebaseDatabase database1 = FirebaseDatabase.getInstance();
                        Query query = database1.getReference().child(RIDERS_PATH + "/" + FirebaseAuth.getInstance().getCurrentUser().getUid()
                                + "/" + RESERVATION_PATH).child(stringArrayList.get(position));

                        query.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if (snapshot.exists()) {
                                    snapshot.getRef().removeValue();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                        DatabaseReference myRef1 = FirebaseDatabase.getInstance().getReference(RESTAURATEUR_INFO + "/" +
                                orderRiderItem.getKeyRestaurant() + RESERVATION_PATH);

                        HashMap<String, Object> orderMap = new HashMap<>();
                        orderMap.put(stringArrayList.get(position), new OrderItem(orderRiderItem.getKeyRestaurant(), orderRiderItem.getAddrCustomer().toLowerCase(), orderRiderItem.getTotPrice(),
                                STATUS_UNKNOWN, orderRiderItem.getDishes(), orderRiderItem.getTime(), 0));
                        myRef1.updateChildren(orderMap);
                    }).create()
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return orderRiderItems.size();
    }


    public void viewOrder(String id) {
        AlertDialog reservationDialog = new AlertDialog.Builder(context).create();
        LayoutInflater inflater = LayoutInflater.from(context);
        final View view = inflater.inflate(R.layout.dishes_list_dialog, null);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        Query query = database.getReference().child(RIDERS_PATH + "/" + FirebaseAuth.getInstance().getCurrentUser().getUid()
                + "/" + RESERVATION_PATH).child(id).child("dishes");

        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    ArrayList<String> dishes = new ArrayList<>();

                    for (DataSnapshot d : dataSnapshot.getChildren()) {
                        dishes.add(d.getKey() + " - Quantity: " + d.getValue(Integer.class));
                    }

                    recyclerView_ordered = view.findViewById(R.id.ordered_list);
                    mAdapter_ordered = new RecyclerAdapterOrdered(reservationDialog.getContext(), dishes);
                    layoutManager = new LinearLayoutManager(reservationDialog.getContext());
                    recyclerView_ordered.setAdapter(mAdapter_ordered);
                    recyclerView_ordered.setLayoutManager(layoutManager);

                    view.findViewById(R.id.back).setOnClickListener(e -> reservationDialog.dismiss());
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("RESERVATION", "Failed to read value.", error.toException());
            }
        });

        reservationDialog.setView(view);
        reservationDialog.setTitle("Order");
        reservationDialog.show();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView profile_image, confirm_reservation, delete_reservation, open_reservation;
        private TextView listview_address, listview_toPay, textView_time, delivery_address;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            profile_image = itemView.findViewById(R.id.profile_image);
            confirm_reservation = itemView.findViewById(R.id.confirm_reservation);
            delete_reservation = itemView.findViewById(R.id.delete_reservation);
            open_reservation = itemView.findViewById(R.id.open_reservation);
            listview_address = itemView.findViewById(R.id.listview_address);
            listview_toPay = itemView.findViewById(R.id.listview_toPay);
            textView_time = itemView.findViewById(R.id.textView_time);
            delivery_address = itemView.findViewById(R.id.delivery_address);
        }
    }
}
